
var hilexmultilem = {};



hilexmultilem.settings = {
	
	multilemmata: {
		"group": "Multiple lemmata"
	},
	
	multiple_lemmata_analyses: {
		"group": "Multiple lemmata"
	},
	
	multiple_lemmata_analyses_view: {
		"group": "Multiple lemmata"
	},
	
	multiple_lemmata_analysis_parts: {
		"group": "Multiple lemmata"
	}
	
};


hilexmultilem.config = {
	
	multilemmata: {
		
	},
	
	multiple_lemmata_analyses: {
		
	},
	
	multiple_lemmata_analyses_view: {
		
	},
	
	multiple_lemmata_analysis_parts: {
		
	}
};