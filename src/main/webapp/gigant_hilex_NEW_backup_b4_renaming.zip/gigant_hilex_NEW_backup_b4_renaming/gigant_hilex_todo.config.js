// list of tables that must be hidden or visible (don't use both, it's a matter of what's the most convenient)
oHiddenTablesList = [];
oShowOnlyTables = [];

// global
bForceExactCount = true;

var sDateFormat = "YYYY-MM-DD";

var aHilexActors = [
                    "Boukje",
                    "Dirk",
                    "Frank",
                    "Griet",
                    "Jesse",
                    "Katrien D.",
                    "Katrien Vp.",
                    "Marjolijn",
                    "Mathieu",
                    "Roland",
                    "Rob T.",
                    "Wil"
                    ];

var aTopics = 		[""]; // values will be read from webservice

var aStatusCodes = ["", // default 
                    "Nieuw", 
                    "Overleg nodig", 
                    "Op de lange baan", 
                    "In ontwikkeling", 
                    "Test", 
                    "Kan naar productie", 
                    "Klaar", 
                    "Databewerking bezig", 
                    "Gesloten", 
                    "Toekomstplan"];

var aStatusColorCodes = ["#000000", // default 
                         "#F92611", // Nieuw
                         "#B22222", // Overleg nodig
                         "#008B8B", // Op de lange baan
                         "#4169E1", // In ontwikkeling
                         "#4169E1", // Test
                         "#088A08",// Kan naar productie
                         "#000000", // Klaar
                         "#4169E1", // Databewerking bezig
                         "#000000", // Gesloten
                         "#000000"]; // Toekomstplan



//make sure have read the subset names

function updateTopics(){
	
	// get the topic names from the database
	
	fn.callFunction("get_topics", [], function(response){
		
		var aSuggestionsArr = 
	          (response["get_topics"]).split("|");
		
		// update global array
		aTopics = aSuggestionsArr;
		
		//conf.changeTableConfigValue("todo", "topic", "choosefrom", aTopics);
		
		// update the todo table if it's already loaded,
		// so the subsets values are available straight away
		
		if (fn.tableExists("todo"))
			{
			fn.refreshTable("todo");
			}
		
		});
}


// table general settings
oTableSettingsList = {
		
		
		
		"todo_log": {
			
			
			"columns_sorting": {"modification_date": "desc", "modification_time": "desc"}
			
		},
		
		"topics": {
			
			"nice_name": "Standaard-topics om uit te kiezen in de Todo-lijst",
			
			"displaylength": "50",
			
			"columns_sorting": {"topic": "asc"},
			
			"size": "60%",
			
			"button_0":{
				
				"name": "Voeg topic toe",
				"click": function(t){
					
					fn.prompt("Voer gegevens in", ["topic", "topic omschrijving"], ["<geef de topic een naam>", ""], 

							function(){
								
								var sTopic = 		fn.getPromptBoxInput("topic");
								var sDescription =	fn.getPromptBoxInput("topic omschrijving");
								
								// first show the new subset in the table
								
								fn.insertIntoDatabase(t, {"topic": sTopic , "topic_description": sDescription}, null, function(){
									
									fn.goToTheRightPage(t, "topic", sTopic);
									
									updateTopics();
								});
						
					});
					
				}
			},
			
			"button_1":{
				
				"name": "Verwijder selectie",
				"click": function(t){
					
					if (fx.getNumberOfSelectedRows(t) > 0)
						{
						fn.confirm("Let op", "Dit is af te raden. Weet u zeker dat u deze rijen wilt verwijderen?", 
								
							// yes we're sure
								
							function(){
							
								var oSelection = fx.getSelectedRowsFrom(t);
								oSelection.every(function(){
									var oCurrentRow = this;
									var bLastRow = fx.isLastRowOf(oCurrentRow, oSelection);
									fx.removeFromDatabaseGivenARow(this, function(){
										if (bLastRow) 
											{
											fn.refreshTable(t);
											
											updateTopics();
											}
									})
									
								});
							}, 
							
							// no, cancel!
							
							function(){
								fn.message("OK", "Operatie door gebruiker geannuleerd");
							})
						}					
				}
			}

		},
		
		
		
		
		
		"todo": {
			
			"columns_order": [
				"id",
				"priority",
				"invoerdatum",
				"topic",
				"taak",
				"opmerkingen",
				"wie",
				"planning",
				"status_datum",
				"status_code",
				"status_details"				
			                  ],
			
			"nice_name": "Todo lijst",
			
			"callback": function(t){
				
				var oRows = 		fx.getAllRows(t);
				
				oRows.every(function(i){
					
					var oRow = this;
					
					var sStatusCode = fx.getDataFromCellInRow(oRow, "status_code");
					
					// choices: "Nieuw", "Overleg nodig", "Op de lange baan", "In ontwikkeling", "Test", "Klaar", "Databewerking bezig", "Gesloten", "Toekomstplan"
					
					var iStatusCodeIndex = $.inArray(sStatusCode, aStatusCodes);
					var sColorCode = aStatusColorCodes[iStatusCodeIndex];
					
					$( fx.getCellNode(oRow, "taak") ).css("color", sColorCode);						
					$( fx.getCellNode(oRow, "opmerking") ).css("color", sColorCode);
					$( fx.getCellNode(oRow, "status_code") ).css("color", sColorCode);
					
					if (sStatusCode == 'Gesloten')
						{
						var sTableName = fn.getTableName(t);
						var aColNames = mt.getListOfVisibleColumnsOf(sTableName);
						for (var i=0; i<aColNames.length; i++)
							{
							var sColName = aColNames[i];
							if (sColName != "status_code")
								$( fx.getCellNode(oRow, sColName) ).css("opacity", "0.5").editable('disable');
							}											
						}
				});
			},
			
			"repeat_callback": true,
			
			"columns_sorting": {
				"id": "asc"
			},
			
			"button_0": {
				"name": "Ticket toevoegen",
				"click": function(t){
					
					var sTime = fn.getCurrentTimestamp(sDateFormat);
					fn.insertIntoDatabase(t, 
							{
							"invoerdatum": sTime,
							"status_datum": sTime,
							"status_code": "Nieuw"
							}, 
							"id", function(response){
								
								fn.cleanTableCache(t, function(){
									
									var sId = response;
									
									fn.addDrawCallback(t, function(){
										
										var oRow = fx.getRowWhereIdIs(t, sId);
										var iRowNumber = fx.getRowNumberOnScreen(oRow);
										kf.setActiveRowNumber(iRowNumber);
									});
									
									fn.goToTheRightPage(t, "id", response);
								});
								
								
							});
				}
			},
			
			"button_1":{
				
				"name": "Verwijder selectie",
				"click": function(t){
					
					fn.confirm("Verwijder selectie", "Alleen foute tickets mogen weg. Tickets horen anders gesloten te worden. Weet u zeker dat u deze tickets wilt verwijderen?", function(){
						
						var oRows = fx.getSelectedRowsFrom(t);
						
						oRows.every(function(){
							
							var oRow = this;				
							var bLastRow = fx.isLastRowOf(oRow, oRows);
							
							fx.removeFromDatabaseGivenARow(oRow, function(){	
								if (bLastRow) 
									fn.refreshTable(t);
							});
														
							
						});	// end of loop
						
					});	// end of confirm					
					
				}
			},
			
			"button_2":{
				"name": "Toon topics-lijst",
				"bgcolor": "grey",
				"click": function(t){
					fn.callDatabase("topics", {}, function(){
						fn.scrollToTable("topics");
					});
					
				}
			},
			
			"button_3": {
				"name": "Verberg gesloten tickets",
				"bgcolor": "yellow",
				"textcolor": "black",
				"click": function(t){
					var sCurrentLabel = fn.getNameOfButtonAtIndex(t, 3);
					
					if (sCurrentLabel == "Verberg gesloten tickets")
						{
						var aFiltered = aStatusCodes.filter(function(value, index, arr){
						    return value != 'Gesloten';
						});
						
						fn.callDatabase(t, {"status_code": "^("+aFiltered.join("|")+")$"});
						fn.setCustomButtonName(t, 3, "Toon alle tickets");
						
						conf.changeTableConfigValue("todo", "status_code", "filter", "^("+aFiltered.join("|")+")$");
						conf.changeTableConfigValue("todo", "status_code", "keepfilter", true);
						}
					else
						{
						conf.changeTableConfigValue("todo", "status_code", "keepfilter", false);
						
						fn.callDatabase(t, {"status_code": ""});
						fn.setCustomButtonName(t, 3, "Verberg gesloten tickets");
						
						}
				}
			}
		}
		
}

//configuration at column level
oTableConfigurationList = {
		
		
		
		"topics": {
			
			"topic": {
				"editable": true,				
				"editcallback": function(t, n, value){
					updateTopics();
				}
			},
			
			"topic_description": {
				"editable": true
			}
		},
		
		
		
		"todo": {
			
			"priority": {
				"editable": true,
				"editcallback": function(t, n, value){
					fn.callFunction("get_number_of_prio_tickets", [], function(resp){
						
						var iNrPrio = parseInt(resp["get_number_of_prio_tickets"]);
						var iMaxPrioAllowed = 10;
						if (value == 'Prio' && iNrPrio>=iMaxPrioAllowed)
							{
							fn.message("Let op", "Let op: "+iNrPrio+" tickets zijn reeds als 'Prio' aangemerkt (max toegestaan: "+iMaxPrioAllowed+").<BR><BR>Als te veel tickets prioriteit hebben, zijn prioriteiten niet meer helder.")
							}
					});
				}
			},
			
			"id": {
				
			},
			
			"invoerdatum":{
				"editable": getHttpParams().get("test")=='true' // in development, this is editable, otherwise it isn't
			},
			
			"topic": {
				
				"click": function(t, n){
					
					var sCellContent = fn.getDataFromCellNode(n);
					var aAlreadyChosen = sCellContent.split("; ");
					
					var categoriesToChooseFrom = aTopics.concat("[zelfde als vorige rij]");
					
					fn.promptSelect("Maak een keuze", categoriesToChooseFrom, aAlreadyChosen, 
							function(response){
								fn.cleanTableCache(t, function(){
									
									// remove the empty choice, if other options were chosen as well
									if (response.length>1 && response.indexOf("")>-1)
										response.splice( response.indexOf(""), 1 );
									
									var sChosenItems = response.join('; ');
									
									if (sChosenItems.indexOf("[zelfde als vorige rij]")>-1)
										{
										sChosenItems = "";
										var nPreviousNode = $(n).parent().prev().get();
										sChosenItems = fn.getDataFromCellInRowNode(nPreviousNode, "topic");
										}
									
									fn.updateDatabaseGivenANode(n, {"topic": sChosenItems}, function(){
										fn.refreshTable(t);
									});
								});
								
							}, 
							function(){
								// Canceled by user
								// do nothing
							});
				}
			},
			
			"taak": {
				"editable": true,
				"editcallback": function(t, n, value){
					fn.cleanTableCache(t, function(){
						fn.refreshTable(t);
					});
				}
			},
			
			"opmerkingen": {
				"editable": true
			},
			
			"wie": {
				
				"click": function(t, n){
					
					var sCellContent = fn.getDataFromCellNode(n);
					var aAlreadyChosen = sCellContent.split("; ");
					
					var categoriesToChooseFrom = aHilexActors.concat("[zelfde als vorige rij]");;
					
					fn.promptSelect("Maak een keuze", categoriesToChooseFrom, aAlreadyChosen, 
							function(response){
						
								// remove the empty choice, if other options were chosen as well
								if (response.length>1 && response.indexOf("")>-1)
									response.splice( response.indexOf(""), 1 );
						
								var sChosenItems = response.join('; ');
								
								if (sChosenItems.indexOf("[zelfde als vorige rij]")>-1)
									{
									sChosenItems = "";
									var nPreviousNode = $(n).parent().prev().get();
									sChosenItems = fn.getDataFromCellInRowNode(nPreviousNode, "wie");
									}
								
								fn.updateDatabaseGivenANode(n, {"wie": sChosenItems}, function(){
									fn.refreshTable(t);
								})
							}, 
							function(){
								// Canceled by user
								// do nothing
							});
				}
			},
			
			"status_datum": {
				"editable": getHttpParams().get("test")=='true' // in development, this is editable, otherwise it isn't
			},
			
			"status_code":{
				
				//"editable": true,
				//"choosefrom": aStatusCodes,
				
				"click": function(t, n){
					
					var sStatusCode = fn.getDataFromCellNode(n);
					fn.promptSelect(["Status code", "Kies passende statuscode"], aStatusCodes, [sStatusCode], 
							function(response){
								var sNewStatusCode = (response.length>0 ? response[0]: "");
								fn.updateDatabaseGivenANode(n, {"status_code": sNewStatusCode}, function(){
									
									// if the ticket is closed, priority goes back to 'normal'
									// (in such a way that only truly 'prio' tickets get in sight when one is searching for those
									if (sNewStatusCode == 'Gesloten')
										fn.updateDatabaseGivenANode(n, {"priority": "Normal"});
									
									// update the status date as soon as some change was made to this field
									var sTime = fn.getCurrentTimestamp(sDateFormat);
									fn.updateDatabaseGivenANode(n, {"status_datum": sTime}, function(){
										fn.refreshTable(t);
									});
									
								});
							}, 
							function(){
								// on cancel, do nothing
							}, 
							true);
					
				}
			},
			
			"status_details": {
				"editable": true,
				"editcallback": function(t, n, value){
					
					// update the status date as soon as some change was made to this field
					var sTime = fn.getCurrentTimestamp(sDateFormat);
					fn.updateDatabaseGivenANode(n, {"status_datum": sTime}, function(){
						fn.refreshTable(t);
					});
				}
			},
			
			"planning": {
				"editable": true
			}
			
			
		}
		
};


$(document).ready(function() {
	
	updateTopics();
	
	fn.callDatabase("todo");
	
	// force exact count
	// we need to set it at regular interval because at each table update it is automatically set back to false (for sake of speed)
	setInterval(function(){ bForceExactCount = true; }, 1000);
	
});