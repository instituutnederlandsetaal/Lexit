
var hilexdocs = {};


hilexdocs.settings = {
	
	documents: {
		"group": "Onder de motorkap"
	}
};

hilexdocs.config = {
	
	documents: {
		
	}
};