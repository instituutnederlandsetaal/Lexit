// list of tables that must be hidden or visible (don't use both, it's a matter of what's the most convenient)
oHiddenTablesList = [];
oShowOnlyTables = ["analyzed_wordforms", "documents", "lemmata", "lemmata_and_paradigma", "multilemmata",
				 "marijke_spelling_giganthilex_differences",
				 "multiple_lemmata_analyses", "multiple_lemmata_analyses_view", "multiple_lemmata_analysis_parts",
				 "token_attestations", "token_attestations_worktable", "wordforms", 
				 "modified_lemmata_view", "modified_paradigm_view", "modified_attestations_view",
				 "ontbrekende_citaten", "double_quotations_id_to_check",
				 "mnw_wordforms_parts_of_speech", "mnw_lemma_parts_of_speech" ,
				 "missing_mnw_quotes_in_hilex", 
				 "wordforms_to_diminutives",
				 "possible_groups",
				 "lemmata_without_paradigm",
				 "quotation_section_id_of_token_attestations_with_clitics", "fishy_wordforms",
				 "ticket_179_possible_doubled_lemmata", "lemma_to_variants", "thomas_new_fabulous_table", "thomas_new_fabulous_table_premium"];



// Array's to store the locked lemmata of the current view
// Those array's get updated at each table draw
var aCurrentLemmaViewLocks = 		new Array();
var aCurrentParadigmaViewLocks =	new Array();

// notes key
var notesKey = "a";
var taNotesKey = "a";



// list of pid for diminutives job
var listOfPids4DiminutivesJob = null;
var diminutiveGroupsCursor = 0;
var iNumberOfPidsDiminutives = null;


// chosen super lemma storage
var sChosenSuperLemId;

// create a unique multibuilder_id
// (needed so the table used for building multiple lemmata can't be used by more than one user at the time:
//  we create a unique table and remove it afterwards)
var sMultiBuilderId = Math.floor(1000000*Math.random());
var sMultiBuilderTable = 'temp_multilemmata_builder_'+sMultiBuilderId;

// Autocomplete configuration for Multilemmata Builder
// see: http://stackoverflow.com/questions/5077409/what-does-autocomplete-request-server-response-look-like
// http://stackoverflow.com/questions/18677536/jeditable-and-jquery-ui-autocomplete
var sAutoCompleteSelector = "#prompt_lemma1, #prompt_lemma2, #prompt_lemma3, #prompt_lemma4, #prompt_lemma5";


// general

// ==============================================================================
// april 1 module
var oneAprilTestDate = new Date();
var oneAprilMonth = oneAprilTestDate.getUTCMonth() + 1; //months from 1-12
var oneAprilDay = oneAprilTestDate.getUTCDate();
var oneAprilYear = oneAprilTestDate.getUTCFullYear();

var iWait10Minutes = 10 * 60 * 1000; // 10 min x 60 sec x 1000 millisec

if (oneAprilDay == 1 && oneAprilMonth ==4){
	setTimeout(function(){
		fn.message("LET OP", "Uw Lex'it soldo is op (restant: 0).<BR><BR>U kunt vandaag helaas niet verder werken.<BR><BR>Probeer het morgen nog eens!", function(){
			window.open("https://nl.wikipedia.org/wiki/1_april");
		})
	}, iWait10Minutes);
}
// ==============================================================================


// append styling to document

// Huisstijl!
fn.setBalk(true, null, "Icon_HiLex_small.gif");

fn.setProjectFont("Verdana, sans-serif, gtb", "10pt");


// trick: https://stackoverflow.com/questions/524696/how-to-create-a-style-tag-with-javascript
var docHead = document.head || document.getElementsByTagName('head')[0];
var style = document.createElement('style');
var css =	"td.linebrk {white-space: normal; max-width: 220px !important} "+	// needed to keep some columns narrow enough
			"td.linebrk_wf {white-space: normal; max-width: 200px !important} "+
			"td.block {display: block}";

docHead.appendChild(style);
style.type = 'text/css';
if (style.styleSheet){
  // This is required for IE8 and below.
  style.styleSheet.cssText = css;
} else {
  style.appendChild(document.createTextNode(css));
}


// make sure commas are set right, like a space after, but no space before! 
function setCommasRight(x){
	return x.replace(/,([^ ])/g, ", $1").replace(/([ ]+),/g, ",").replace(/,([ ]+)/g, ", ");
}


// ----------------------------------------------------------------------------------
// get library

$.getScript((paramsHash.get("test")!='true' ? "../lexit2_config/" : "") + paramsHash.get("db") + ".library.js")
.done(function(){
	
	// set autocompletes for  MNW pos translation  job

	fn.setAutoComplete("mnw_lemma_parts_of_speech", "correction_pos", false, "get_wnt_lemma_pos_for_select", "|", ":::");

	fn.setAutoComplete("mnw_wordforms_parts_of_speech", "correction_pos", false, "get_wnt_wordform_pos_for_select", "|", ":::");
	

	$(document).on(
	   "focus", 
	   sAutoCompleteSelector, 
	   function(event) {
	   	
	   	$(event.target).autocomplete({
	       	
	   		delay: 750,
	   		minLength: 2,
	   		source: function(request, response){
		    	
		    	fn.callFunction("api.get_lemmata_from_prefix", [fn.quote(request.term), fn.quote(sWdbForMultilemBuilder)], 
		    			function(func_resp){  
		    		
		    		var aSuggestionsArr = 
		    			(func_resp["get_lemmata_from_prefix"]).split("|");
		    		
		    		response($.map(aSuggestionsArr, function (item) {
		                return {
		                    label: item,
		                    value: item
		                };
		            }));
		    	});
		    },
		    open: function( event, ui ) {
		    	$(this).autocomplete('widget').putInFront();
		        return false;
		    },
		    select: function( event, ui ) {
		    	
		    	// read the dictionary the chosen lemma belongs to
		    	var sSuggestionWdb = (ui.item["label"]).replace(/.+, .+ \(([A-Za-z]+) .+, id:.+$/, '$1');
		    	// remove 'n' (new) extension for comparison with other parts
		    	sSuggestionWdb = sSuggestionWdb.replace(/n$/, '');
		    	
		    	// if no sWdbForMultilemBuilder-filter was set yet (because multilemmata builder is empty)
		    	// set it now!
		    	if (sWdbForMultilemBuilder == '')
		    		sWdbForMultilemBuilder = sSuggestionWdb;
		    	
		    	// check if lemma selection meets the dictionary requirement 
		    	// (must be the same dictionary as previously chosen lemmata)
		    	if (sSuggestionWdb != sWdbForMultilemBuilder)
		    		{
		    		fn.message("Let op!", "Alle gekozen delen moeten '"+sWdbForMultilemBuilder+"'-lemmata zijn!");
		    		}
		    }
		});
	       
	   }
	);




	// check if working in Hilex is allowed now
	fn.callFunction("api.test_sync", [], function(response){
		
		if (response["test_sync"] != "Synchronisatie staat AAN"){
			fn.message("LET OP", "Let op: Hilex is heel even uit de lucht (er wordt een update gedraaid). Kom over een paar minuten terug.", function(){
				$("#selected_source").remove();
				$("#indicator").remove();
			});
		}
		
	});
	
});

// ----------------------------------------------------------------------------------










// table general settings
oTableSettingsList = {

		"thomas_new_fabulous_table": {
			"group": "Klus",

			"width": "50%",

			"column_sorting": {"complex": "asc", "simplex": "asc"}
		},

		"thomas_new_fabulous_table_premium": {
			"group": "Klus",

			"width": "50%",

			"column_sorting": {"complex": "asc", "simplex": "asc"}
		},


		"lemma_to_variants": {

			"columns_sorting": {"modern_lemma": "asc", "lemma_id": "asc", "lemma_variant": "asc"},

			"width": "80%",

			"button_0": {
				"name": "Voeg variant toe",
				"click": function(t){

					var nRow = fn.getFirstSelectedRowNodeFrom(t);

					if (nRow == null || nRow.length == 0){

						fn.message("Let op", "Kies één lemma waaraan een variant toegekend moet worden");
					}
					else {

						var iLemmaId = fn.getDataFromCellInRowNode(nRow, "lemma_id");
						var sLemma = fn.getDataFromCellInRowNode(nRow, "modern_lemma");
						var sWdb = fn.getDataFromCellInRowNode(nRow, "wdb");

						fn.prompt(
							["Voeg nieuwe variant toe", "Voer één of meer nieuwe varianten. Indien nodig, gebruik een komma als scheidingsteken"], 
							["Varianten"],
							[sLemma], 
							function(resp){
								
								fn.closeDialog();

								fn.callFunction("api.get_variants_of_lemma", [iLemmaId], function(varResp){

									// parse response
									var sLemAndVariants = varResp["get_variants_of_lemma"];

									var aLemAndVariants = sLemAndVariants.split("###");
									var aVariantsAlreadyThere = aLemAndVariants.length > 1 ?
										(aLemAndVariants[1]).split(", ")
										:
										[];


									fn.showProcessingMsg(t);
									var aNewVariants = (setCommasRight(resp["Varianten"])).split(", ");


									// remove known variants from input
									aNewVariants = aNewVariants.filter(function(x){
										return aVariantsAlreadyThere.indexOf(x) < 0;
									});


									// process variants to be inserted
									for (var i=0; i<aNewVariants.length; i++){

										fn.insertIntoDatabase(t, {"lemma_id": iLemmaId, "modern_lemma": sLemma, "wdb": sWdb, "lemma_variant": aNewVariants[i]}, 
											function(){ 
												if (i == aNewVariants.length-1){
													setTimeout(function(){fn.refreshTable(t);}, 500);
												}											
											}
										); 
									}

									// but if there are none (probably because of filtering of pre-existing variants) then do refresh only
									if (aNewVariants.length == 0)
										fn.refreshTable(t);

								});

								

							} 
						); // end of prompt

					}
				}
			},

			"button_1": {
				"name": "Verwijder variant",
				"click": function(t){

					var aRows = fn.getSelectedRowNodesFrom(t);
					$(aRows).each(function(){
						var nRow = this;
						fn.removeFromDatabaseGivenANode(nRow, function(){
							if (fn.isLastNodeOf(nRow, aRows))
								setTimeout(function(){fn.refreshTable(t);}, 500);
						});
					});

				}
			},

			"callback": function(t){
				
				var iPreviousLemId = null;
				var bPreviousMultiple = false;
				var aRows = fn.getAllRowNodes(t);
				
				// make sure the user can easily distinguish groups in the view
				// by adding lines between groups, and adding color to groups with more than one member
				
				var iIdx = 0;
				var aColor = ["#0404B4", "#61210B"];
				var aBold = ["bold", "normal"];
				
				$(aRows).each(function(i){
					
					var thisRow = this;

					var iLem = fn.getDataFromCellInRowNode(thisRow, "lemma_id");
					var bMultiple = (fn.getDataFromCellInRowNode(thisRow, "multiple") == 't');
					var bNewGroup = (iLem != iPreviousLemId);
					
					// have we got a new group of variants?
					// add a top border on the first row of the group
					if (i>0 && bNewGroup){
						$(thisRow).find("td").css("border-top", "1px solid black");	
					}

					// compute next group rendering idx 
					// if we're in a new group
					if (bMultiple && bNewGroup){
						if (bPreviousMultiple) iIdx++;	
						if (iIdx > 1) iIdx = 0;
					}

					// apply appropriate style
					// if we have multiples, make groups visible with another color
					$(thisRow).find("td")
						.css("font-weight", (bMultiple ? aBold[iIdx]:"normal"))
						.css("color", (bMultiple ? aColor[iIdx] : "#000000"));

					
					// we need to remember this lemma-id for next round
					// so as to detect when we're dealing with another group
					iPreviousLemId = iLem;
					bPreviousMultiple = bMultiple;

				});
			},

			"repeat_callback": true
		},

		"ticket_179_possible_doubled_lemmata": {
			
			"creation_date": "20200305",
			
			"group": "Klus",
			
			"width": "70%"
		},

		lemmata_without_paradigm: {
			
			"group": "Klus",
			
			"creation_date": "20190702",
			
			"callback": function(t){
				
				fn.callFunction("get_lem_without_paradigm_stats", [], function(resp){
					
					var sTableName = fn.getTableName(t);
					var sStatusDivId = "lem_stats";
					$("#"+sTableName+"_wrapper .top").find("#"+sStatusDivId).remove();
					$("#"+sTableName+"_wrapper .top").append(
							$("<div></div>")
							.attr("id", sStatusDivId)
							.css("width", "200px")	
							.css("text-align", "center")			
							.css("color", "black")
							.append($("p").css("text-decoration", "none")
								)
							);
					
					$("#"+sTableName+"_wrapper .top #"+sStatusDivId).append(
							$("<span></span>")
							.html("Vreugdemeter: "+resp["get_lem_without_paradigm_stats"])
							.css("font-size", "120%")
							);
					
					$("#"+sTableName+"_wrapper .top #"+sStatusDivId)
					.css("border", "1px dotted black")
					.css("position", "relative")
					.css("top", "10px")
					.css("left", "210px");
					
				});
				
			},
			
			"repeat_callback": true
			
		},
		
		possible_groups: {
			
			"creation_date": "20190710",
			
			"column_sorting": {"diff": "desc"},
			
			"columns_order": ["id", "attestation_ids", "quotation_section_id", "quote", "onsetoffset", "wordforms_arr", "wordform",
			                  "lemma_id", "multiple_lemmata_analysis_id", "modern_lemma", 
			                  "levenshtein_dist", "diff", "group_id", "true_count", "opmerking", "klaar"],
			
			"group": "Klus",
			
			"callback": function(t){
				
				highlightAllQuotes(t);
				
				fn.callFunction("get_nr_of_possible_groups_yet_to_process", [], function(resp){
					
					var sTableName = fn.getTableName(t);
					var sStatusDivId = "lem_stats";
					$("#"+sTableName+"_wrapper .top").find("#"+sStatusDivId).remove();
					$("#"+sTableName+"_wrapper .top").append(
							$("<div></div>")
							.attr("id", sStatusDivId)
							.css("width", "200px")	
							.css("text-align", "center")			
							.css("color", "black")
							.append($("p").css("text-decoration", "none")
								)
							);
					
					$("#"+sTableName+"_wrapper .top #"+sStatusDivId).append(
							$("<span></span>")
							.html("Vreugdemeter: "+resp["get_nr_of_possible_groups_yet_to_process"])
							.css("font-size", "120%")
							);
					
					$("#"+sTableName+"_wrapper .top #"+sStatusDivId)
					.css("border", "1px dotted black")
					.css("position", "relative")
					.css("top", "10px")
					.css("left", "210px");
					
				});
			},
			"repeat_callback": true,
			
			"button_0": {
				
				"name": "Deze rijen zijn allemaal klaar",
				"click": function(t){
					
					var oRows = fx.getAllRows(t);
					oRows.every(function(){
						
						var oCurrentRow = this;
						var lastRow = fx.isLastRowOf(oCurrentRow, oRows);
						
						var checkboxvalue = fx.getDataFromCellInRow(oCurrentRow, "klaar");
						if (checkboxvalue == 'f')
							fx.toggleCheckbox(oCurrentRow, "klaar");
						fx.updateDatabaseGivenACellOrRow(oCurrentRow, {"klaar": true});
						
					});					
					
					
				}
				
			}
			
		},

		
		missing_mnw_quotes_in_hilex:{
			
			"group": "MNW quotes check",
			
			"creation_date": "20181116"
				
		},

		mnw_lemma_parts_of_speech:{
			
			"group": "MNW parts of speech",
			
			"width": "60%",
			
			"creation_date": "20181108"
		},
		
		mnw_wordforms_parts_of_speech:{
			
			"group": "MNW parts of speech",
			
			"width": "60%",
			
			"creation_date": "20181108"
		},
	
		double_quotations_id_to_check: {
			
			"group": "Klus",
			
			"creation_date": "2018 10 02", "finished_date": "no", "processed_date": "no",
			
			"width": "60%"
				
		},
			
		ontbrekende_citaten: {
			
			"group": "Klus",
			
			"creation_date": "2018 09 20", "finished_date": "ca 2018 10 02", "processed_date": "2018 10 02",
			
			"width": "60%"
		},

		multilemmata: {
			
			"button_0":{
				"name": "Verwijder multilemma",
				"click": function(t){
					
					if (fn.getNumberOfSelectedRowNodes(t) == 0)
						{
						fn.message("Let op", "Kies een multilemma om te verwijderen.");
						}
					else
						{
						fn.confirm("Zeker weten?", "Alle geselecteerde multilemmata zullen nu verwijderd worden," +
								"en ook de daaraan gekoppelde paradigmata", function(){							
							
							var oSelection = fx.getSelectedRowsFrom(t);
							
							oSelection.every(function(){	
								
								var oThisRow = this;
								var sMultiLemId = 	fx.getDataFromCellInRow(oThisRow, "multiple_lemmata_analysis_id");
								var bLastRow =		fx.isLastRowOf(oThisRow, oSelection);
																
								fn.callFunction("api.delete_multiple_lemma", [sMultiLemId], function(){								
									if (bLastRow) 
										fn.refreshTable(t);									
									});
							
								});							
							
							});
						
						
						
						}
					
					
				}
			}
			
		},

		
		modified_lemmata_view: {
			
			"group": "log",
			
			"columns_sorting": {"modification_date": "desc", "modification_time": "desc"},
			
			"button_0":{
				"name": "Lemma en paradigma herstellen",
				"click": function(t){
					
					fn.confirm("Zeker weten?", 
							"Weet u het zeker? Als de log groot is, kan deze operatie enige tijd kosten.", 
							function(){
						
						var oRowSelection = fx.getSelectedRowsFrom(t);
						
						oRowSelection.every(function(){
							
							var oCurrentRow =	this;
							var sLemmaId = 		fx.getDataFromCellInRow(oCurrentRow, "lemma_id");
							
							fn.callFunction("api.restore_lemma_and_paradigm_and_ids", [sLemmaId],  
									function(){
								
										if (fx.isLastRowOf(oCurrentRow, oRowSelection))
											fn.refreshTable(t);
							});
						});
					});
				}
			}
		},
		
		modified_paradigm_view:{
			
			"group": "log",
			
			"columns_sorting": {"modification_date": "desc", "modification_time": "desc"},
			
			"button_0":{
				"name": "Woordvorm herstellen",
				"click": function(t){
					
					fn.confirm("Zeker weten?", "Weet u het zeker?", 
							function(){
						
						var oRowSelection =  fx.getSelectedRowsFrom(t);
						
						oRowSelection.every(function(){
							
							var oCurrentRow =	this;							
							var sAwfId =		fx.getDataFromCellInRow(oCurrentRow, "analyzed_wordform_id");
							fn.callFunction("api.restore_wordform", [sAwfId],  
									function(){
										if (fx.isLastRowOf(oCurrentRow, oRowSelection))
											fn.refreshTable(t);
							});
						});
					});
				}
			}
		},
		
		modified_attestations_view: {
			
			"group": "log",
			
			"columns_sorting": {"modification_date": "desc", "modification_time": "desc"},
			
			"button_0":{
				"name": "Attestatie herstellen",
				"click": function(t){
					
					fn.confirm("Zeker weten?", "Weet u het zeker?", 
							function(){
						
						var oRowSelection =  fx.getSelectedRowsFrom(t);
						
						oRowSelection.every(function(){
							
							var oCurrentRow =	this;							
							var sAttId =		fx.getDataFromCellInRow(oCurrentRow, "attestation_id");
							fn.callFunction("api.restore_attestation", [sAttId],  
									function(){
										if (fx.isLastRowOf(oCurrentRow, oRowSelection))
											fn.refreshTable(t);
							});
						});
					});
				}
			}
			

		},

		
		
		lemmata: {

			"width": "95%",

			"columns_order": [
				"lemma_id",
				"modern_lemma",
				"lemma_variants",
				"gloss",
				"persistent_id",
				"lemma_part_of_speech",
				"ne_label",
				"portmanteau_lemma_id",
				"language_id",
				"is_multiple",
				"wdb",
				"super_lem_id",
				"opmerking",
				"online",
				"multi_part"
			],
			
			"keyup" : {
				
				"@": function(t){
					
					var oRow = fx.getFirstSelectedRowFrom(t);
					$(fx.getCellNode(oRow, "lemma_part_of_speech")).click();
				},
				
				"insert": function(t){
					
					var oRow = fx.getFirstSelectedRowFrom(t);					
					$(fx.getCellNode(oRow, "lemma_part_of_speech")).click();
				},
				
				"f9": function(t){
					
					var oRow = 			fx.getFirstSelectedRowFrom(t);					
					var sWdb = 			fx.getDataFromCellInRow(oRow, "wdb");
					var iPersistentId =	fx.getDataFromCellInRow(oRow, "persistent_id");
					
					// remove illegal string parts, which would cause an error in the GTB 
					sWdb = sWdb.replace("_DIM", "");
					
					window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+iPersistentId);
				},
				
				
				"uparrow": function(t){
					
					// small delay otherwise it won't work
					$("#"+t).delay(500).queue(function(){

						var oRow = 		fx.getFirstSelectedRowFrom(t);
						var sLemmaId =	fx.getDataFromCellInRow(oRow, "lemma_id");
						
						if ( !isNaN(sLemmaId) )
							{
							fn.callDatabase("token_attestations_worktable", {"lemma_id": sLemmaId});
							}						

						$(this).dequeue();
					});					
					
				},
				"downarrow": function(t){
					
					// small delay otherwise it won't work
					$("#"+t).delay(500).queue(function(){

						var oRow = 		fx.getFirstSelectedRowFrom(t);
						var sLemmaId =	fx.getDataFromCellInRow(oRow, "lemma_id");
						
						if ( !isNaN(sLemmaId) )
						{
						fn.callDatabase("token_attestations_worktable", {"lemma_id": sLemmaId});
						}

						$(this).dequeue();
					});
				}
			},
			
			"callback": function(t){
				
				// lemmata locks
				
				var sTableName = fn.getTableName(t);
				
				// build the UNlock button if it doesn't exist yet
				// (superuser only)
				if ( superUser() && fn.getIndexOfButtonNamed(sTableName, "(Un)lock")<0){
					fn.addCustomButton(sTableName, {
						"name": "(Un)lock",
						"bgcolor": "#F5D0A9",
						"click": function(t){
							
							var oSelectedRows = fx.getSelectedRowsFrom(t);
							
							oSelectedRows.every(function(){
								
								var sLemmaId = 		fx.getRowId(this);
								var sMultilemmaId =	null;
								var bLastRow = 		fx.isLastRowOf(this, oSelectedRows);
								
								if ($.inArray( comma(sLemmaId, sMultilemmaId), aCurrentLemmaViewLocks ) >-1){
									fn.callFunction(
										"api.unlock_lemma", 
										[deEmpty(sLemmaId), deEmpty(sMultilemmaId)], 
										function(){
											if(bLastRow) fn.refreshTable(t);
										}
									);
								}
								else {
									fn.callFunction(
										"api.lock_lemma", 
										[deEmpty(sLemmaId), deEmpty(sMultilemmaId)], 
										function(){
											if(bLastRow) fn.refreshTable(t);
										}
									);
								}
								
							});
							
						}
					});

				}

				var aLemmaIds = (fn.getDataFromColumn(t, "lemma_id"));				
				var sLemmaIds = aLemmaIds.join(", ");

				// make sure the value of 'multi_part' is up to date,
				// and render the current values (normally a table refresh would be good enough
				// but not here, in the callback, as this would trigger an infinite loop)
			
				fn.callFunction("api.update_multi_lem_window", [sLemmaIds], function(resp){

					resp = resp["update_multi_lem_window"];

					var aLemIdsAndMultiLem = resp.split('###');
					for (var i=0; i<aLemIdsAndMultiLem.length; i++){

						var aLemIdAndMultiLem = (aLemIdsAndMultiLem[i]).split(":");
						var iLem = parseInt( aLemIdAndMultiLem[0] );
						var bMultiLem = aLemIdAndMultiLem[1] == 'true';
						var nRow = fn.getRowNodeWhere(t, {"lemma_id": iLem});
						var iMultiLemIdx = $.inArray("multi_part", mt.getListOfVisibleColumnsOf(t));
						$(nRow).find("td").eq(iMultiLemIdx).find("input").eq(0).prop("checked", bMultiLem);
					}


					// Apply lemmata locks
			
					var aLemmaIdsArr =	new Array();
					var oRows = 		fx.getAllRows(t);
					
					oRows.every(function(i){
						
						var sLemmaId =		fx.getRowId(this);
						var sMultilemmaId =	null;
						
						aLemmaIdsArr.push( comma(sLemmaId, sMultilemmaId) );
					});
					
					
					// get the list of locked lemmata
					// and modify the rows accordingly
					fn.callFunction("api.get_locks_of_lemmata", [ fn.quote( aLemmaIdsArr.join("|") ) ], function(){
						
						aCurrentLemmaViewLocks = (fn.getFunctionOutput()[0]).split("|");
						
						oRows.every(function(i){
							
							var oThisRow = 		this;
							var sLemmaId = 		fx.getRowId(oThisRow);
							var sMultilemmaId =	null;
							
							if ( $.inArray( comma(sLemmaId, sMultilemmaId), aCurrentLemmaViewLocks ) >-1 )
								{
								var aVisibleCells = mt.getListOfVisibleColumnsOf(fn.getTableName(t));
								
								for (var j=0; j<aVisibleCells.length; j++)
									{
									var sCurrentColumnName = aVisibleCells[j];
									
									// we mustn't lock the comment field
									if (sCurrentColumnName == 'opmerking')
										continue;
									
									
									// make sure we can't edit the locked lemmata								
									var sCellType =	fx.getCellType(oThisRow, sCurrentColumnName);								
									var eCell =		fx.getCellNode(oThisRow, sCurrentColumnName);
									
									if (sCellType == 'text')
										{									
										$(eCell).editable('disable');
										$(eCell).css("opacity", "0.5");
										}
									else if (sCellType == 'checkbox')
										{
										$(eCell).find("input").attr("disabled", "disabled");
										$(eCell).css("opacity", "0.5");
										}
									else if (sCellType == 'selectbox')
										{
										$(eCell).editable('disable');
										$(eCell).css("opacity", "0.5");
										}
									}					
								
								}						
							
						});
						
					}); // end of function call
					
				});
				
			},
			"repeat_callback": true,
			
			"button_0": {
				
				"name": "Multilemmata_builder",
				"bgcolor": "yellow",
				"textcolor": "green", 
				"click": function(t){
					
					// make sure that row selection is activated
					var bRowSelectionActivated = fn.rowsSelectionIsAllowed(t);
					if ( !bRowSelectionActivated)
						fn.clickOnButton(t, "selectionbutton");
					
					// open the multilemmata_builder view
					fn.closeTable("token_attestations_worktable", function(){
						
						fn.callFunction("api.create_multilemmata_builder", [fn.quote(sMultiBuilderTable)], function(){
							fn.callDatabase(sMultiBuilderTable, {}, function(){
								
								fn.callDatabase("lemmata", {}, function(){
									
									fn.alignTables(sMultiBuilderTable, "lemmata", function(){
										
										fn.clickOnButton("lemmata", "selectionbutton");
									});
								})
							});
							
						});
						
					});
					
					
				}
			},
			"button_1":{
				"name": "Verwijder lemma",
				"click": function(t){
					
					if (fn.getNumberOfSelectedRowNodes(t) == 0)
						{
						fn.message("Let op", "Kies een lemma om te verwijderen.");
						}
					else
						{
						fn.confirm("Zeker weten?", "Alle geselecteerde lemmata zullen nu verwijderd worden," +
								"en ook de daaraan gekoppelde paradigmata", function(){							
							
							var oSelection = fx.getSelectedRowsFrom(t);
							
							oSelection.every(function(){	
								
								var sLemId = 	fx.getDataFromCellInRow(this, "lemma_id");
								var bLastRow =	fx.isLastRowOf(this, oSelection);
								
								fn.callFunction("api.delete_lemma", [sLemId], function(){									
									if (bLastRow) 
										fn.refreshTable(t);									
									});
							
								});							
							
							});
						
						
						
						}
					
					
				}
			},
			"button_2": {
				
				"name": "Maak superlem aan",
				"tooltip": "Ken dit lemma een nieuw super_lemma_id toe.",
				"bgcolor": "green",
				"click": function(t){
						
					var oRow = fx.getFirstSelectedRowFrom(t);
					
					if ( oRow.count()!=1 )
						{
						fn.message("Let op!", "Kies één lemma!" +
								"Dan pas kan daar een nieuw superlemma aan toegekend worden");
						}
					else
						{
						var sLemmaId = fx.getDataFromCellInRow(oRow, "lemma_id");
						var sModlem = fx.getDataFromCellInRow(oRow, "modern_lemma");
						
						fn.confirm("Maak superlemma aan", "Er zal een nieuw super_lemma_id worden aangemaakt, " +
								"en daar zal het lemma '"+sModlem+"' onder komen te hangen. " +
								"Weet u zeker dat u dat wilt?", function(){
							
							fn.callFunction("api.create_new_super_lem", [sLemmaId], function(){
								
								fn.refreshTable(t, function(){
									if (fn.tableExists("lemmata_and_paradigma"))
										fn.refreshTable("lemmata_and_paradigma");
								});
								
							});
							
						});
						
						
						}						
					
				}				
				
			},
			"button_3": {
				
				"name": "Gekozen superlem:",
				"bgcolor":"yellow",
				"textcolor": "red",
				"click": function(t){
					
					var oRow = fx.getFirstSelectedRowFrom(t);
										
					if ( oRow.any() ){
						// remember chosen superlemma, and show it on the screen
						var sSuperLemId = fx.getDataFromCellInRow(oRow, "super_lem_id");
						
						fn.callFunction("api.get_super_lem", [sSuperLemId], function(resp){
							var sSuperLemma = resp["get_super_lem"];
							fn.setCustomButtonName(t, 3, "Gekozen superlem:<b>"+sSuperLemma+"</b>");
							sChosenSuperLemId = sSuperLemId;
						});						
						
					}
					
					// press shift + click to cancel parent selection 
					if (kf._getPressedKey() == 'shift'){
						fn.setCustomButtonName(t, 3, "Gekozen superlem:");
						sChosenSuperLemId = null;
					}
				}
			},
			"button_4":{
				"name": "Link lem & superlem",
				"bgcolor":"red",
				"textcolor": "yellow",
				"click": function(t){
					
					fn.confirm("Lemma en superlemma linken", "Weet u het zeker?", function(){
						
						if (sChosenSuperLemId != null) {

							var oRows = fx.getSelectedRowsFrom(t);
							if (oRows.any()){
								
								oRows.every(function(){
									
									var sLemId = 	fx.getDataFromCellInRow(this, "lemma_id");
									var bLastNode =	fx.isLastRowOf(this, oRows);
									
									fn.updateDatabaseGivenFieldValues("lemmata", 
											{"lemma_id": sLemId}, 
											{"super_lem_id": sChosenSuperLemId}, 
											
											function(){
												
												if (bLastNode){												
													fn.refreshTable(t, function(){
														if (fn.tableExists("lemmata_and_paradigma"))
															fn.refreshTable("lemmata_and_paradigma");
													});
												}
											});
									});			
								
							}
							else {
								fn.message("Let op", "Kies een of meerdere lemmata!");							
							}
							
						}
						else {
							fn.message("Let op", "Kies eerst een superlemma!");
						}
						
					});					
					
				}
			},
			"button_5": {
				
				"name": "Unlink superlem",
				"bgcolor":"red",
				"textcolor": "yellow",
				"click": function(t){
					
					
					fn.confirm("Lemma en superlemma unlinken", "Weet u het zeker?", function(){
						
						var oRows = fx.getSelectedRowsFrom(t);
						if (oRows.any()){
							
							oRows.every(function(){
								
								var sLemId = 	fx.getDataFromCellInRow(this, "lemma_id");
								var bLastNode =	fx.isLastRowOf(this, oRows);
								
								fn.callFunction("api.create_new_super_lem", [sLemId], function(){
									
									if (bLastNode){												
										fn.refreshTable(t, function(){
											if (fn.tableExists("lemmata_and_paradigma"))
												fn.refreshTable("lemmata_and_paradigma");
										});
									}
									
								});
							
							});
						}
						else {
								fn.message("Let op", "Kies een of meerdere lemmata!");
						}
						
					});
					
				}				
			}
		},
		


		
		token_attestations: {
			
			"callback": function(t){
				_highlightAllQuotes(t);
			},
			"repeat_callback": true
		},
			
		
		token_attestations_worktable: {

			"width":"98%",

			"prereset_callback": function(t){
				fn.setCustomButtonName(t, 8, "L: ");
				fn.setCustomButtonName(t, 9, "R: ");
			},
			
			"callback": function(t){
				highlightAllQuotes(t);
				
				var aFilters = fn.getFilters(t);
				
				if (typeof aFilters["opmerking"] != 'undefined' && aFilters["opmerking"] == 'clitic')
					{
					buildHappinessCounter(t, "get_clitics_yet_to_be_processed", "tok_att_work_clitics");
					}								
			},
			"repeat_callback": true,
			
			"columns_order": [
				//"job_page",
				"attestation_ids",
				"quote",
				"quote_vector",
				"quotation_section_id",
				"analyzed_wordform_ids",
				"lemma_id",
				"multiple_lemmata_analysis_id",
				"modern_lemma",
				"derivation_ids",
				"document_id",
				"doorvoeren",
				"onsetoffset",
				"wordform",
				"wordform_alphabetic",
				"group_id",	  
				"wdb",
				"online",
				"old_quotation_section_id",
				"citblock_id",
				"notes",
				"opmerking",
				"analyzed_wordform_ids_arr",
				"process_now",
				"token_previous",
				"token_next"
			],
			
			// ordering by lemma_id, quote and onset, is needed when one wants to process a list of quotes string in the worktable,
			// without accessing the lemma/paradigm table 
			// (t.i. one wants to process quotes just like in the Impact Attestation tool)
			
			"columns_sorting": {
				"modern_lemma": "asc",
				"quote": "asc"
			},
			
			
			"button_0": {
				
				"name": "Koppel aan lemma",
				"tooltip": "Koppel de geselecteerde attestatie aan het in 'lemmata_and_paradigma' geselecteerde lemma",
				"click": function(t){
					
					// get the selected lemma from the lemmata and paradigma table
					
					if (	fx.getNumberOfSelectedRows("lemmata_and_paradigma") == 1
							&&
							fx.getNumberOfSelectedRows(t) == 1 )
						{
						
						var oSelectedLemma =	fx.getFirstSelectedRowFrom("lemmata_and_paradigma");
						var sLemma = 			fx.getDataFromCellInRow(oSelectedLemma, "modern_lemma");
						var sLemId = 			fx.getDataFromCellInRow(oSelectedLemma, "lemma_id");
						var sMultiLemId = 		fx.getDataFromCellInRow(oSelectedLemma, "multiple_lemmata_analysis_id");
						
						// warn the user he/she is about to assign some attestations
						// to another lemma 
						
						fn.confirm("Let op", 
								"De geselecteerde attestaties zullen gekoppeld worden aan " +
								(sLemId != '' ? "" : "multiple ") + "lemma '"+sLemma+"' " +
								"met ID " + (sLemId != '' ? sLemId : sMultiLemId) + ".<br>" +
								"Weet u zeker dat u dat wilt?", 
								function(){
							
									fn.showProcessingMsg(t);
							
									// make sure we have null values where needed
									if (sLemId == '') 		sLemId = 'NULL';
									if (sMultiLemId == '')	sMultiLemId = 'NULL';
										
									
									// We will process each attestation one at the time
									// So we must call a function which will call
									// itself again as a callback, but with the
									// following id to process, till all ids are processed
									
									// get list of ids of attestations to process									
									
									var aAttestationIdsToProcess = new Array();	
									
									var oSelectedAtts = fx.getSelectedRowsFrom(t);
									oSelectedAtts.every(function(){
										aAttestationIdsToProcess.push( fx.getRowId(this) );
									});
									
									
									// process each selected attestation now
																		
									var functionToRepeat = function(i){										
										
										fn.updateDatabaseGivenFieldValues(t, 
												{"attestation_ids": "^"+aAttestationIdsToProcess[i]+"$"}, 
												{"lemma_id": sLemId, "multiple_lemmata_analysis_id": sMultiLemId}, 
												 
												function(){
													
													if ( (i+1) < aAttestationIdsToProcess.length )
														{
														functionToRepeat(i+1);
														}
													else
														{
														// refresh to see the results!
														fn.refreshTable("lemmata_and_paradigma");
														fn.refreshTable(t);
														}
												});
										
									};
									
									// start the function now
									// it will increment its own argument till all ids are processed
									//
									// NB: this function call will cause
									// a function to be triggered that will copy
									// the analyzed wordforms to the new lemma
									// and remove the original analyzed wordforms
									// if there is no attestation left attached to it
									
									functionToRepeat(0);
									
											
							});
						}

					// or... get the selected lemma from the lemmata table

					else if (	fx.getNumberOfSelectedRows("lemmata") == 1
							&&
							fx.getNumberOfSelectedRows(t) == 1 )
						{
						
						var oSelectedLemma =	fx.getFirstSelectedRowFrom("lemmata");
						var sLemma = 			fx.getDataFromCellInRow(oSelectedLemma, "modern_lemma");
						var sLemId = 			fx.getDataFromCellInRow(oSelectedLemma, "lemma_id");
						var sMultiLemId = 		'NULL';
						
						// warn the user he/she is about to assign some attestations
						// to another lemma 
						
						fn.confirm("Let op", 
								"De geselecteerde attestaties zullen gekoppeld worden aan " +
								"lemma '"+sLemma+"' met ID " + sLemId + ".<br>" +
								"Weet u zeker dat u dat wilt?", 
								function(){
							
									fn.showProcessingMsg(t);
							
									// make sure we have null values where needed
									if (sLemId == '') 		sLemId = 'NULL';										
									
									// We will process each attestation one at the time
									// So we must call a function which will call
									// itself again as a callback, but with the
									// following id to process, till all ids are processed
									
									// get list of ids of attestations to process									
									
									var aAttestationIdsToProcess = new Array();	
									
									var oSelectedAtts = fx.getSelectedRowsFrom(t);
									oSelectedAtts.every(function(){
										aAttestationIdsToProcess.push( fx.getRowId(this) );
									});
									
									
									// process each selected attestation now
																		
									var functionToRepeat = function(i){										
										
										fn.updateDatabaseGivenFieldValues(t, 
												{"attestation_ids": "^"+aAttestationIdsToProcess[i]+"$"}, 
												{"lemma_id": sLemId, "multiple_lemmata_analysis_id": sMultiLemId}, 
												 
												function(){
													
													if ( (i+1) < aAttestationIdsToProcess.length )
														{
														functionToRepeat(i+1);
														}
													else
														{
														// refresh to see the results!
														fn.refreshTable("lemmata_and_paradigma");
														fn.refreshTable(t);
														}
												});
										
									};
									
									// start the function now
									// it will increment its own argument till all ids are processed
									//
									// NB: this function call will cause
									// a function to be triggered that will copy
									// the analyzed wordforms to the new lemma
									// and remove the original analyzed wordforms
									// if there is no attestation left attached to it
									
									functionToRepeat(0);
									
											
							});
						}

					// or... get the selected lemma from the multilemmata table

					else if (	fx.getNumberOfSelectedRows("multilemmata") == 1
							&&
							fx.getNumberOfSelectedRows(t) == 1 )
						{
						var oSelectedLemma =	fx.getFirstSelectedRowFrom("multilemmata");						
						var sLemma = 			fx.getDataFromCellInRow(oSelectedLemma, "modern_lemma");
						var sLemId = 'NULL';
						var sMultiLemId = 		fx.getDataFromCellInRow(oSelectedLemma, "multiple_lemmata_analysis_id");
						
						// warn the user he/she is about to assign some attestations
						// to another lemma 
						
						fn.confirm("Let op", 
								"De geselecteerde attestaties zullen gekoppeld worden aan " +
								"multiple lemma '"+sLemma+"' " +
								"met ID " + sMultiLemId + ".<br>" +
								"Weet u zeker dat u dat wilt?", 
								function(){
							
									fn.showProcessingMsg(t);
									
									// We will process each attestation one at the time
									// So we must call a function which will call
									// itself again as a callback, but with the
									// following id to process, till all ids are processed
									
									// get list of ids of attestations to process									
									
									var aAttestationIdsToProcess = new Array();	
									
									var oSelectedAtts = fx.getSelectedRowsFrom(t);
									oSelectedAtts.every(function(){
										aAttestationIdsToProcess.push( fx.getRowId(this) );
									});
									
									
									// process each selected attestation now
																		
									var functionToRepeat = function(i){										
										
										fn.updateDatabaseGivenFieldValues(t, 
												{"attestation_ids": "^"+aAttestationIdsToProcess[i]+"$"}, 
												{"lemma_id": sLemId, "multiple_lemmata_analysis_id": sMultiLemId}, 
												 
												function(){
													
													if ( (i+1) < aAttestationIdsToProcess.length )
														{
														functionToRepeat(i+1);
														}
													else
														{
														// refresh to see the results!
														fn.refreshTable("lemmata_and_paradigma");
														fn.refreshTable(t);
														}
												});
										
									};
									
									// start the function now
									// it will increment its own argument till all ids are processed
									//
									// NB: this function call will cause
									// a function to be triggered that will copy
									// the analyzed wordforms to the new lemma
									// and remove the original analyzed wordforms
									// if there is no attestation left attached to it
									
									functionToRepeat(0);
									
											
							});
						
						}
					else
						{
						fn.message("Let op", "U moet wel een attestatie én een lemma kiezen!");
						}
				}
				
			},
			
			
			"button_1":{
				
				"name": "Zoek ander lemma",
				"click": function(t){
					
					var n = fn.getFirstSelectedRowNodeFrom(t);
					
					var sAttestationIds =	fn.getDataFromCellInRowNode(n, "attestation_ids");
					var sWordform =			removeTags(fn.getDataFromCellInRowNode(n, "wordform"));
					var sWdb = 				fn.getDataFromCellInRowNode(n, "wdb");
					var sLemmaId =			fn.getDataFromCellInRowNode(n, "lemma_id");
					var sMultiLemmaId =		fn.getDataFromCellInRowNode(n, "multiple_lemmata_analysis_id");
					var sOpmerking =		fn.getDataFromCellInRowNode(n, "opmerking");
					
					fn.prompt( ["Zoek ander lemma", "Tik hier de gewenste lemmavorm in"], ["Vorm"], [sWordform],
							
							function(resp){

								var sWordform = resp["Vorm"];
								sWordform = sWordform.replace(/ *\+ */g, '+').trim();

								var bAllowAmbiguity = sWordform.indexOf("|")>=0;

								// do we have to deal with ambiguity?
								if (bAllowAmbiguity) {

									fnBuildAmbiguousLemmaAndLinkIt(sAttestationIds, sWordform, sWdb, sOpmerking);
								}

								// no ambiguity to deal with
								else {

									fn.callFunction("api.search_for_other_lemma", 
											[fn.quote(sWordform), (sLemmaId == ''?'NULL':sLemmaId), fn.quote(sWdb), (sMultiLemmaId == ''?'NULL':sMultiLemmaId)], 
											function(response){
										
										// found lemmata are given in a ^^^-separated string
										
										var foundLemmata = response["search_for_other_lemma"];
										var foundLemmataArr = foundLemmata.split("^^^");
										

										// no lemma was found, build a new one?

										if (foundLemmata == '') {
											fn.confirm("Lemma ontbreekt", "Er is geen ander lemma met deze vorm in het "+sWdb+".<br><br>Wilt u '"+sWordform+"' aanmaken?", 
												function(){

													// ready to link:
													
													// we were searching for a lemma
													if (sWordform.indexOf("+")<0) {
														fnBuildLemmaAndLinkIt(sAttestationIds, sWordform, sWdb, sOpmerking);
													}
													// we were searching for a multiple lemma
													else {
														fnBuildMultiLemmaAndLinkIt(sAttestationIds, sWordform, sWdb, sOpmerking);
													}
												},
												function(){
													fn.message("OK", "Bewerking door gebruiker geannuleerd");
												}
											);
											
										}
										

										// a (multi)lemma matching the input was found,
										//
										// now allow the user
										//    - to choose it 
										// or - to build a new one

										else										
											{
											var aAllOptions = new Array();
											
											fnBuildOptionsForOneLemma( aAllOptions, foundLemmataArr );
											
											aAllOptions.push("Maak een ander lemma aan");		
											
											fn.promptSelect(["Kies het juiste lemma", "Kies het juiste lemma (Houd SHIFT ingedrukt bij klikken om meer info te tonen):"], 
													aAllOptions, [], 
													function(response){
														// nothing
													}, 
													function(){
														fn.message("OK", "Geannuleerd");
													}, 
													function(selectedText){
														
														var toets = kf._getPressedKey();
														
														// need information the lemma ?

														if (toets == 'shift') {
															fnShowLemmaInfo(selectedText, sWdb);
														}

														// assign lemma_id!

														else {
															// if we have a lemma_id, make a link with that lemma
															if (selectedText.indexOf("(lem_id:")>-1){

																var iBegin = selectedText.indexOf("lem_id:") + "lem_id:".length;
																var iEnd = selectedText.indexOf(")", iBegin);
																var sLemId = selectedText.substring(iBegin, iEnd);

																
																// ready to link:

																fn.updateDatabaseGivenFieldValues(t, 
																		{"attestation_ids": "^"+sAttestationIds+"$"}, 
																		{"lemma_id": sLemId, "multiple_lemmata_analysis_id": null},
																		function(){
																			
																			fn.updateDatabaseGivenFieldValues(t, 
																					{"attestation_ids": "^"+sAttestationIds+"$"}, 
																					{"opmerking": sOpmerking.replace(/nieuw +lemma/, "lemma verwerkt")},
																					function(){
																						fn.closeDialog();
																						fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemId});
																						fn.refreshTable(t);
																						
																					});
																			
																		});
															}

															// if we have a multi-lem_id, make a link with that multiple lemma
															else if (selectedText.indexOf("(multi_lem_id:")>-1) {

																var iBegin = selectedText.indexOf("multi_lem_id:") + "multi_lem_id:".length;
																var iEnd = selectedText.indexOf(")", iBegin);
																var sMultiLemId = selectedText.substring(iBegin, iEnd);

																
																// ready to link:
																
																fn.updateDatabaseGivenFieldValues(t, 
																		{"attestation_ids": "^"+sAttestationIds+"$"}, 
																		{"lemma_id": null, "multiple_lemmata_analysis_id": sMultiLemId},
																		function(){
																			
																			fn.updateDatabaseGivenFieldValues(t, 
																					{"attestation_ids": "^"+sAttestationIds+"$"}, 
																					{"opmerking": sOpmerking.replace(/nieuw +lemma/, "lemma verwerkt")},
																					function(){
																						fn.closeDialog();
																						fn.callDatabase("lemmata_and_paradigma", {"multiple_lemmata_analysis_id": sMultiLemId});
																						fn.refreshTable(t);
																						
																					});
																			
																		});
															}
															// if the selectedText contains NO lemma_id, we have to build a new lemma and so on
															else {
																// we were searching for a lemma
																if (sWordform.indexOf("+")<0) {
																	fnBuildLemmaAndLinkIt(sAttestationIds, sWordform, sWdb, sOpmerking);
																}
																// we were searching for a multiple lemma
																else {
																	fnBuildMultiLemmaAndLinkIt(sAttestationIds, sWordform, sWdb, sOpmerking);															
																}
															}
															
														} // end of choice handling
														
													});
											
											}
										
									});
								}
								
							}, 
							function(){
								fn.message("Geannuleerd", "Operatie door gebruiker geannuleerd.");
							});
					
				}
				
			},
			
			
			"button_2":{
				
				"name": "Schoonvegen",
				"tooltip": "Verwijder alle attestaties uit de citaat",
				"click": function(t){
					
					fn.confirm("Geselecteerde citaten schoonvegen", "Weet u het zeker?", function(){
						
						var oRows = fx.getSelectedRowsFrom(t);
						oRows.every(function(){
							
							var oRow = this;
							var bLastRow = fx.isLastRowOf(oRow, oRows);
							
							// remove indexes
							fx.updateDatabaseGivenACellOrRow(oRow, 
									{ "onsetoffset": "none" }, 
									function(){
										if (bLastRow)
											{
											if (oRows.count()>1)
												{
												fn.refreshTable(t);
												}
											else
												{
												var sRecordId = fx.getRowId( fx.getFirstSelectedRowFrom(t) );
												fn.getRecord(t, sRecordId, function(record){													
													fx.putDataIntoCell(oRow, "onsetoffset", record["onsetoffset"]);
													fx.putDataIntoCell(oRow, "quote", record["quote"]);
													});
												}
											}
											
									});
						});
						

						
					});					
				}
				
			},
			
			"button_3":{
				
				"name": "Verwijder selectie",
				"click": function(t){
					
					var oSelection = fx.getSelectedRowsFrom(t);
					
					if (oSelection.count()==0) {
						fn.message("Let op", "U moet attestaties selecteren!");
					}
					else {
						
						fn.confirm("Verwijder selectie", "Weet u zeker dat u deze attestatie(s) wilt verwijderen?", function(){							
							
							oSelection.every(function(){
								
								var oRow = this;
								var bLastOne = fx.isLastRowOf(oRow, oSelection);

								var attIds = fx.getDataFromCellInRow(oRow, "attestation_ids");

								fn.callFunction('api.set_lemma_string_for_attestation_worktable', [fn.quote(attIds), true], function(){

									fx.removeFromDatabaseGivenARow(oRow, function(){

											if (bLastOne){
												fn.refreshTable(t);
												fn.refreshTable("lemmata_and_paradigma");
											}									
									
									});
								});
								
							});
							
						});
						
						
						
					}
					
				}
			},
			
			"button_4":{
				
				"name": "Dupliceer",
				"click": function(t){
					
					var oRow = fx.getFirstSelectedRowFrom(t);
					
					if ( oRow.any() )
						{
						fn.confirm("Dupliceer citaat", "Weet u het zeker?", function(){
							
							fn.showProcessingMsg(t);
							
							var sAttIds = fx.getDataFromCellInRow(oRow, "attestation_ids");
							fn.callFunction('api.copy_attestation', [sAttIds], function(){							
									fn.refreshTable(t);
									fn.removeProcessingMsg(t);
								});
							
						});
						
						
						}
					
				}
			},
			
			"button_5": {
				
				"name": "Supersonisch!",
				"bgcolor": "yellow",
				"textcolor": "black",
				"click": function(t){
					
					var sQuoteSearchString = fn.getValueOfFilterBox(t, "quote");
					
					if (sQuoteSearchString == '')
						{
						fn.message("Let op", "Deze functie zoekt in het quote-veld. Tik eerst een zoekwaarde in de zoekbox.");
						}
					else
						{
						var aQuoteVectorSearch = sQuoteSearchString.split(" ");
						for (var i=0; i<aQuoteVectorSearch.length; i++)
							{
							aQuoteVectorSearch[i] = aQuoteVectorSearch[i]+":*";
							}
						var sQuoteVectorSearch = aQuoteVectorSearch.join(" & ");
						fn.addFilters(t, {"quote_vector": sQuoteVectorSearch})
						
						fn.callDatabase(t, {"quote": sQuoteSearchString, "quote_vector": sQuoteVectorSearch});
						
						}
					
					
					
				}
			},
			
			"button_6": {
				
				"name": "Ongeattesteerd",
				"click": function(t){
					fn.clearAllFilters(t);
					fn.callDatabase(t, {"onsetoffset": "\\y0,0\\y"});
				}
			},

			"button_7": {
				
				"name": "Notes",
				"click": function(t){
					
					fn.prompt("Notes config", ["Notes code"], [taNotesKey], 
							function(){
								taNotesKey = fn.getPromptBoxInput("Notes code");
							}, 
							function(){
								fn.message("OK", "Operatie door gebruiker geannuleerd");
							});
				}
			},

			"button_8": {
				"name": "L:",
				"tooltip": "Klik om op linker-context te sorteren; herhaal klik voor andere volgorde",
				"bgcolor": "lightblue",
				"click": function(t, n){

					var sSortDir = fn.getSortingDirectionOf(t, "token_previous");
					var aSortingDirs = ["asc", "desc", "asc_reverse", "desc_reverse"];

					var iCurrentSortingDir = $.inArray(sSortDir, aSortingDirs);
					iCurrentSortingDir++;
					if (iCurrentSortingDir == aSortingDirs.length) iCurrentSortingDir = 0;
					sSortDir = aSortingDirs[iCurrentSortingDir];
					fn.setCustomButtonName(t, 8, "L: "+sSortDir);
					fn.setCustomButtonName(t, 9, "R: "); // cancelled

					fn.setSorting(t, {"token_previous": sSortDir});
					fn.refreshTable(t);
				}
			},

			"button_9": {
				"name": "R: ",
				"tooltip": "Klik om op rechter-context te sorteren; herhaal klik voor andere volgorde",
				"bgcolor": "lightblue",
				"click": function(t, n){
					var sSortDir = fn.getSortingDirectionOf(t, "token_next");
					var aSortingDirs = ["asc", "desc", "asc_reverse", "desc_reverse"];

					var iCurrentSortingDir = $.inArray(sSortDir, aSortingDirs);
					iCurrentSortingDir++;
					if (iCurrentSortingDir == aSortingDirs.length) iCurrentSortingDir = 0;
					sSortDir = aSortingDirs[iCurrentSortingDir];
					fn.setCustomButtonName(t, 9, "R: "+sSortDir);
					fn.setCustomButtonName(t, 8, "L: "); // cancelled

					fn.setSorting(t, {"token_next": sSortDir});
					fn.refreshTable(t);

				}
			}
			
		},
		
		quotation_section_id_of_token_attestations_with_clitics: {
			
			"width": "50%",
			
			"displaylength": 1,
			
			
			"group": "Klus",
			
			"creation_date": "2019 07 10", "finished_date": "2019 07 18", "processed_date": "2019 07 18",
			
			"callback": function(t){		
				
				$("#quotation_section_id_of_token_attestations_with_clitics_wrapper").find(".paging_full_numbers").hide();
				
				$("#quotation_section_id_of_token_attestations_with_clitics_dynamic").css("min-height", "auto");
				

				// show counter
				
				var sStats = "Row #"+fn.getCurrentDisplayStart(t);
				
				var sTableName = fn.getTableName(t);
				var sStatusDivId = "dim_stats";
				$("#"+sTableName+"_wrapper .top").find("#"+sStatusDivId).remove();
				$("#"+sTableName+"_wrapper .top").append(
						$("<div></div>")
						.attr("id", sStatusDivId)
						.css("width", "200px")	
						.css("text-align", "center")			
						.css("color", "black")
						.append($("p").css("text-decoration", "none")
							)
						);
				
				$("#"+sTableName+"_wrapper .top #"+sStatusDivId).append(
						$("<span></span>")
						.html(sStats)
						.css("font-size", "120%")
						);
				
				$("#"+sTableName+"_wrapper .top #"+sStatusDivId)
				.css("border", "1px dotted black")
				.css("position", "relative")
				.css("top", "10px")
				.css("left", "210px");
				
				// call other table
				
				
				var nRow = fn.getFirstSelectedRowNodeFrom(t);
				if (nRow == null)
					nRow = fn.getActiveRowNode(t);
				
				var sGroupToFetch = fn.getDataFromCellInRowNode(nRow, "quotation_section_id");
				var sOnsetOffsetToFetch = fn.getDataFromCellInRowNode(nRow, "onsetoffset");
				
				fn.callDatabase("token_attestations_worktable", {"quotation_section_id": "\"exact:"+sGroupToFetch+"\"", "onsetoffset": "\"exact:"+sOnsetOffsetToFetch+"\""});

				
			},
			
			"repeat_callback": true,
			
			"button_0": {
				
				"name": "Vorige",
				"click": function(t){
					
					t.page( 'previous' ).draw( 'page' );
					
				}
				
			},
			"button_1": {
				
				"textcolor": "red",
				"bgcolor": "yellow",
				"name": "Klaar + Volgende",
				"click": function(t){
					
					var nRow = fn.getFirstSelectedRowNodeFrom(t);
					if (nRow == null)
						nRow = fn.getActiveRowNode(t);
					
					fn.updateDatabaseGivenANode(nRow, {"done": true});
					
					t.page( 'next' ).draw( 'page' );
					
				}
				
			},
			"button_2": {
				
				"name": "Volgende",
				"click": function(t){
					
					t.page( 'next' ).draw( 'page' );					
					
				}
				
			}
			
		},
		
		
		lemmata_and_paradigma: {

			"width":"98%",			
			"columns_order": [
			                  	"super_lem_id",
								"superlem",
								"wdb",
								"lemma_id",
								"multiple_lemmata_analysis_id",
								"persistent_id",
								"modern_lemma",
								"lemma_variants",
								"online",
								"full_analysis",
								"lemma_part_of_speech",
								"group_id",
								"analyzed_wordform_id",
								"wordform_id",
								"wordform",
								"part_of_speech",
								"unique_id",
								"opmerking",
								"notes",								
								"wf_online"
								],
								
			"columns_sorting": {
				"super_lem_id": "asc", 
				"modern_lemma": "asc", 
				"persistent_id": "asc", 
				"group_id": "asc",
				"wordform": "asc" },
			
			"callback": function(t){
				
				// groups must be easily recognizable
				highlightGroups(t);
				
				
				// lemmata locks
				
				var sTableName = fn.getTableName(t);
				
				// build the UNlock button if it doesn't exist yet
				// (for superusers only)
				if ( superUser() && fn.getIndexOfButtonNamed(sTableName, "(Un)lock")<0)
					{										
					fn.addCustomButton(sTableName, {
						"name": "(Un)lock",
						"bgcolor": "#F5D0A9",
						"click": function(t){
							
							var oSelectedRows = fx.getSelectedRowsFrom(t);
							
							oSelectedRows.every(function(){
								
								var sLemmaId = 		fx.getDataFromCellInRow(this, "lemma_id");
								var sMultilemmaId =	fx.getDataFromCellInRow(this, "multiple_lemmata_analysis_id");
								var bLastRow = 		fx.isLastRowOf(this, oSelectedRows);
								
								if ($.inArray( comma(sLemmaId, sMultilemmaId), aCurrentParadigmaViewLocks ) >-1)
									{
									fn.callFunction("api.unlock_lemma", 
											[deEmpty(sLemmaId), deEmpty(sMultilemmaId)], 
											function(){
												if(bLastRow) fn.refreshTable(t);
											}
										);
									}
								else
									{
									fn.callFunction("api.lock_lemma", 
											[deEmpty(sLemmaId), deEmpty(sMultilemmaId)], 
											function(){
												if(bLastRow) fn.refreshTable(t);
											}
										);
									}
								
								});
							
							}
						});
					}
				
				
				// apply locks
				
				var aLemmaIdsArr =	new Array();
				var oRows =			fx.getAllRows(t);
				
				oRows.every(function(){				
					
					var sLemmaId = 		fx.getDataFromCellInRow(this, "lemma_id");
					var sMultiLemmaId =	fx.getDataFromCellInRow(this, "multiple_lemmata_analysis_id");
					
					aLemmaIdsArr.push( comma(sLemmaId, sMultiLemmaId) );
				});
				
				// get the list of locked lemmata
				// and modify the rows accordingly
				fn.callFunction("api.get_locks_of_lemmata", [ fn.quote(aLemmaIdsArr.join("|")) ], function(){
					
					aCurrentParadigmaViewLocks = (fn.getFunctionOutput()[0]).split("|");
					
					oRows.every(function(i){
						
						var oRow = 		this;
						var sLemmaId = 		fx.getDataFromCellInRow(oRow, "lemma_id");
						var sMultiLemmaId =	fx.getDataFromCellInRow(oRow, "multiple_lemmata_analysis_id");
						
						
						if ( $.inArray( comma(sLemmaId, sMultiLemmaId), aCurrentParadigmaViewLocks ) >-1 )
							{
							var aVisibleCells = mt.getListOfVisibleColumnsOf(fn.getTableName(t));
							
							for (var j=0; j<aVisibleCells.length; j++)
								{
								var sCurrentColumnName = aVisibleCells[j];
								
								// we mustn't lock the comment field
								if (sCurrentColumnName == 'opmerking')
									continue;
								
								
								// make sure we can't edit the locked lemmata
								var sCellType =	fx.getCellType(oRow, sCurrentColumnName);								
								var eCell =		fx.getCellNode(oRow, sCurrentColumnName);
								
								if (sCellType == 'text')
									{									
									$(eCell).editable('disable');
									$(eCell).css("opacity", "0.5");
									}
								else if (sCellType == 'checkbox')
									{
									$(eCell).find("input").attr("disabled", "disabled");
									$(eCell).css("opacity", "0.5");
									}
								else if (sCellType == 'selectbox')
									{
									$(eCell).editable('disable');
									$(eCell).css("opacity", "0.5");
									}
								}					
							
							}						
						
					});						
					
				}); // end of function call
				
			},
			"repeat_callback": true,
			
			"button_0":{
				
				"name": "Maak lemma aan",
				"click": function(t){
					
					// default persistent id is: GH + date + dot + random number in range [0-999]
					// (eg. GH20160401144225.432)
					var sDefaultPersistentId = 
						"GH"+ fn.getCurrentTimestamp("YYYYMMDD.HHMISS") + 
						"." + Math.floor(Math.random() * 1000);
					
					fn.prompt("Nieuw lemma", 
							["modern_lemma", "part_of_speech", "persistent_id", "wdb"], 
							["", "", sDefaultPersistentId, ""], function(){
						
								var sLemma =		fn.getPromptBoxInput("modern_lemma");
								var sPos =			fn.getPromptBoxInput("part_of_speech");
								var sPersistentId =	fn.getPromptBoxInput("persistent_id");
								var sWdb =			fn.getPromptBoxInput("wdb");

								if (sWdb == 'WNT' && (
									!$.startsWith(sPersistentId, "M") &&
									!$.startsWith(sPersistentId, "A") &&
									!$.startsWith(sPersistentId, "S")
								)){
									fn.message("Let op", sPersistentId+" is geen toegestane PID.<BR><BR>WNT PIDs beginnen met M, A of S");
								}
								else {

									fn.callFunction("api.create_new_lemma", 
										[fn.quote(sLemma), fn.quote(sPos), fn.quote(sPersistentId), fn.quote(sWdb)], 
										function(){
									
											// the lemma was created in the lemmata table 
											// and copied by a trigger to the current table, so make
											// the result visible
											fn.callDatabase(t, {"modern_lemma": "^"+sLemma+"$", "wdb": sWdb});
									
									});
								}
					});
				}
				
			},
			
			"button_1":{
				
				"name": "Verwijder selectie",
				"click": function(t){
					
					fn.confirm("Verwijder selectie", "Weet u zeker dat u deze woordvorm(en) wilt verwijderen?", function(){
						
						var oRows = fx.getSelectedRowsFrom(t);
						
						oRows.every(function(){
							
							var oRow = this;							
							var sAwfId = fx.getDataFromCellInRow(oRow, "analyzed_wordform_id");
							var bLastRow = fx.isLastRowOf(oRow, oRows);
							
							// if the wordform is empty, we need to delete the row
							if (sAwfId == '' || sAwfId == null) 
								{
								fx.removeFromDatabaseGivenARow(oRow, function(){	
									if (bLastRow) 
										fn.refreshTable(t);
									});
								}
							// if we have a true wordform, process it as such
							else
								{
								fn.callFunction("api.delete_analyzed_wordform", [sAwfId], function(){	
									if (bLastRow) 
										fn.refreshTable(t);
									});
								}
														
							
						});	// end of loop
						
					});	// end of confirm					
					
				}
			}, // end of button 1
			
			"button_2": {
				
				"name": "Maak superlem aan",
				"tooltip": "Ken dit lemma een nieuw super_lemma_id toe.",
				"bgcolor": "green",
				"click": function(t){
						
					var oRow = fx.getFirstSelectedRowFrom(t);
					
					if ( oRow.count()!=1 )
						{
						fn.message("Let op!", "Kies één lemma!" +
								"Dan pas kan daar een nieuw superlemma aan toegekend worden");
						}
					else
						{
						var sLemmaId = fx.getDataFromCellInRow(oRow, "lemma_id");
						var sModlem = fx.getDataFromCellInRow(oRow, "modern_lemma");
						
						fn.confirm("Maak superlemma aan", "Er zal een nieuw super_lemma_id worden aangemaakt, " +
								"en daar zal het lemma '"+sModlem+"' onder komen te hangen. " +
								"Weet u zeker dat u dat wilt?", function(){
							
							fn.callFunction("api.create_new_super_lem", [sLemmaId], function(){
								
								fn.refreshTable(t);
								
								});
							
						});
						
						
						}						
					
				}				
				
			},
			"button_3": {
				
				"name": "Gekozen superlem:",
				"bgcolor":"yellow",
				"textcolor": "red",
				"click": function(t){
					
					var oRow = fx.getFirstSelectedRowFrom(t);
										
					if ( oRow.any() )
						{
						// remember chosen superlemma, and show it on the screen
						var sSuperLemId = fx.getDataFromCellInRow(oRow, "super_lem_id");
						var sSuperLemma = fx.getDataFromCellInRow(oRow, "superlem");
						
						fn.setCustomButtonName(t, 3, "Gekozen superlem:<b>"+sSuperLemma+"</b>");
						sChosenSuperLemId = sSuperLemId;
						}
					
					// press shift + click to cancel parent selection 
					if (kf._getPressedKey() == 'shift')
					{
						fn.setCustomButtonName(t, 3, "Gekozen superlem:");
						sChosenSuperLemId = null;
					}
				}
			},
			"button_4":{
				"name": "Link lem & superlem",
				"bgcolor":"red",
				"textcolor": "yellow",
				"click": function(t){
					
					fn.confirm("Lemma en superlemma linken", "Weet u het zeker?", function(){
						
						if (sChosenSuperLemId != null)
						{
						var oRows = fx.getSelectedRowsFrom(t);
						if (oRows.any())
							{
							
							oRows.every(function(){
								
								var sLemId = 	fx.getDataFromCellInRow(this, "lemma_id");
								var bLastNode =	fx.isLastRowOf(this, oRows);
								
								fn.updateDatabaseGivenFieldValues("lemmata", 
										{"lemma_id": sLemId}, 
										{"super_lem_id": sChosenSuperLemId}, 
										
										function(){
											
											if (bLastNode)
												{												
												fn.refreshTable(t);
												}
										});
								});			
							
							}
						else
							{
							fn.message("Let op", "Kies een of meerdere lemmata!");							
							}
						
						
						}
					else
						{
						fn.message("Let op", "Kies eerst een superlemma!");
						}
						
					});					
					
				}
			},
			"button_5": {
				
				"name": "Unlink superlem",
				"bgcolor":"red",
				"textcolor": "yellow",
				"click": function(t){
					
					
					fn.confirm("Lemma en superlemma unlinken", "Weet u het zeker?", function(){
						
						var oRows = fx.getSelectedRowsFrom(t);
						if (oRows.any())
							{
							
							oRows.every(function(){
								
								var sLemId = 	fx.getDataFromCellInRow(this, "lemma_id");
								var bLastNode =	fx.isLastRowOf(this, oRows);
								
								fn.callFunction("api.create_new_super_lem", [sLemId], function(){
									
									if (bLastNode)
										{												
										fn.refreshTable(t);
										}
									
									});
							
								});
							}
						else
							{
								fn.message("Let op", "Kies een of meerdere lemmata!");
							}
						
					});
					
				}				
			},
			"button_6": {
				
				"name": "Multilemmata_builder",
				"bgcolor": "yellow",
				"textcolor": "green", 
				"click": function(t){
					
					fn.callFunction("api.create_multilemmata_builder", [fn.quote(sMultiBuilderTable)], function(){
						fn.callDatabase(sMultiBuilderTable, {}, function(){
							
							fn.callDatabase("lemmata", {}, function(){
								
								fn.alignTables(sMultiBuilderTable, "lemmata", function(){
									
									fn.clickOnButton("lemmata", "selectionbutton");
									
									
									// pre-insert the selected lemma in the multilemmata builder
									// (do it this late, to make sure the multilemmata builder is already available)
									
									var oSelectedLemma = fx.getFirstSelectedRowFrom(t);
									if (oSelectedLemma.any())
										{
										var sLemId = 	fx.getDataFromCellInRow(oSelectedLemma, "lemma_id");
										var sModLem =	fx.getDataFromCellInRow(oSelectedLemma, "modern_lemma");
										var sPos = 		fx.getDataFromCellInRow(oSelectedLemma, "lemma_part_of_speech");
										var sLemWdb =	fx.getDataFromCellInRow(oSelectedLemma, "wdb");
										
										if (sLemId != '' && sLemId != null)
											{
											fn.insertIntoDatabase(sMultiBuilderTable, 
													{
													"lemma_id": sLemId,
													"modern_lemma": sModLem,
													"lemma_part_of_speech": sPos,
													"wdb": sLemWdb
													}, 
													null, 
													function(){												
														
														fn.scrollToTable(sMultiBuilderTable);
														fn.refreshTable(sMultiBuilderTable, function(){
															fn.setFilters("lemmata", {"wdb": sLemWdb}, true);
															fn.refreshTable("lemmata");
														});
													});
											}
										
										}
								});
							})
						});
					});					
					
				}
			},
			"button_7":{
				
				"name": "CLITICS",
				"bgcolor": "pink",
				"textcolor": "black",
				"click": function(t){
					
					fn.clearAllFilters(t);
					fn.setFilters(t, {"multiple_lemmata_analysis_id": "."}, true);
					fn.refreshTable(t);
					
				}
			},
			
			"button_8": {
				"name": "Toon alle attestaties",
				"click": function(t){
					var aAllIds = fn.getDataFromColumn(t, "analyzed_wordform_id");
					fn.callDatabase("token_attestations_worktable", {"analyzed_wordform_ids": "^("+aAllIds.join("|")+")$"});
				}
			},
			
			"button_9": {
				
				"name": "Notes",
				"click": function(t){
					
					fn.prompt("Notes config", ["Notes code"], [notesKey], 
							function(){
								notesKey = fn.getPromptBoxInput("Notes code");
							}, 
							function(){
								fn.message("OK", "Operatie door gebruiker geannuleerd");
							});
				}
			}
			
		},
		
		
		wordforms_to_diminutives_d_notes: {
			"creation_date": "2019 05 07", "finished_date": "ca 2019 06 01", "processed_date": "idem"
		},
		
		wordforms_to_diminutives: {
			
			"selection_button_active": true,
			
			"keyup": {
				
				"pageup": function(t){
					
					if (diminutiveGroupsCursor > 0)
					{
						
					if (kf.isPressed("shift"))	
						{
						diminutiveGroupsCursor = diminutiveGroupsCursor - 5;
						if (diminutiveGroupsCursor<0) diminutiveGroupsCursor = 0; 
						}
					else
						{
						diminutiveGroupsCursor--;
						}
					var sGroupToFetch = listOfPids4DiminutivesJob[diminutiveGroupsCursor];
					fn.callDatabase(t, {"persistent_id": "^"+sGroupToFetch+"$"}, function(){
						
						setTimeout(function(){fn.unselectRowNode(t, 0);}, 500);
						});
					}
				else
					{
					fn.message("Let op", "Vóór de eerste groep is niets.");
					}
				},
				
				"pagedown": function(t){
					
					if (diminutiveGroupsCursor < listOfPids4DiminutivesJob.length-1)
						{
						
						if (kf.isPressed("shift"))
							{
							diminutiveGroupsCursor = diminutiveGroupsCursor + 5;
							if (diminutiveGroupsCursor > listOfPids4DiminutivesJob.length-1) diminutiveGroupsCursor = listOfPids4DiminutivesJob.length-1;
							}
						else
							{
							diminutiveGroupsCursor++;
							}
						
						
						var sGroupToFetch = listOfPids4DiminutivesJob[diminutiveGroupsCursor];
						fn.callDatabase(t, {"persistent_id": "^"+sGroupToFetch+"$"}, function(){
							
							setTimeout(function(){fn.unselectRowNode(t, 0);}, 500);
							});
						}
					else
						{
						fn.message("Let op", "U heeft de laatste groep bereikt");
						}
					
				}
			},
			
			"group": "Klus",
			
			"creation_date": "2019 07 03", "finished_date": "ca 2019 07 18", "processed_date": "2019 07 18",
			
			"callback": function(t){
				
				
				var sTableName = fn.getTableName(t);
				$("#"+sTableName).find("input[type='checkbox']").css("width", "30px").css("height", "30px");
				
				// if we don't have a list of pids to process yet, fetch it!
				if (listOfPids4DiminutivesJob == null)
				{
					fn.callFunction("get_number_of_pids_diminutives", [], function(response){
						iNumberOfPidsDiminutives = response["get_number_of_pids_diminutives"];
					});
					
					fn.callFunction("get_pids_diminutives_not_solved", [], function(response){
						
						listOfPids4DiminutivesJob = (response["get_pids_diminutives_not_solved"]).split(ARG_INTERNAL_SEPARATOR);
						
						diminutiveGroupsCursor = 0;
						
						var sGroupToFetch = listOfPids4DiminutivesJob[diminutiveGroupsCursor];
						
						setTimeout(function(){
							fn.callDatabase(t, {"persistent_id": "^"+sGroupToFetch+"$"}, function(){
								
								setTimeout(function(){fn.unselectRowNode(t, 0);}, 500);
							});
						}, 500);
						

					});
					
				}
				else
				{
					var sStats = "Totaal:"+iNumberOfPidsDiminutives+"<BR>Over aan begin van sessie:"+listOfPids4DiminutivesJob.length + "<BR>In sessie verwerkt:"+ diminutiveGroupsCursor + "";
					
					var sTableName = fn.getTableName(t);
					var sStatusDivId = "dim_stats";
					$("#"+sTableName+"_wrapper .top").find("#"+sStatusDivId).remove();
					$("#"+sTableName+"_wrapper .top").append(
							$("<div></div>")
							.attr("id", sStatusDivId)
							.css("width", "400px")	
							.css("text-align", "center")			
							.css("color", "black")
							.append($("p").css("text-decoration", "none")
								)
							);
					
					$("#"+sTableName+"_wrapper .top #"+sStatusDivId).append(
							$("<span></span>")
							.html(sStats)
							.css("font-size", "120%")
							);
					
					$("#"+sTableName+"_wrapper .top #"+sStatusDivId)
					.css("border", "1px dotted black")
					.css("position", "relative")
					.css("top", "-10px")
					.css("left", "410px");
				
				}
				
			},
			
			"repeat_callback": true,
			
			"button_0": {
				
				"name": "Vorige groep",
				"click": function(t){
					
					if (diminutiveGroupsCursor > 0)
						{
						if (kf.isPressed("shift"))	
							{
							diminutiveGroupsCursor = diminutiveGroupsCursor - 5;
							if (diminutiveGroupsCursor<0) diminutiveGroupsCursor = 0; 
							}
						else
							{
							diminutiveGroupsCursor--;
							}

						var sGroupToFetch = listOfPids4DiminutivesJob[diminutiveGroupsCursor];
						fn.callDatabase(t, {"persistent_id": "^"+sGroupToFetch+"$"}, function(){
							
							setTimeout(function(){fn.unselectRowNode(t, 0);}, 500);
							});
						}
					else
						{
						fn.message("Let op", "Vóór de eerste groep is niets.");
						}
					
				}
				
			},
			
			"button_1": {
				
				"name": "Volgende groep",
				"click": function(t){
					
					if (diminutiveGroupsCursor < listOfPids4DiminutivesJob.length-1)
						{
						if (kf.isPressed("shift"))
							{
							diminutiveGroupsCursor = diminutiveGroupsCursor + 5;
							if (diminutiveGroupsCursor > listOfPids4DiminutivesJob.length-1) diminutiveGroupsCursor = listOfPids4DiminutivesJob.length-1;
							}
						else
							{
							diminutiveGroupsCursor++;
							}

						var sGroupToFetch = listOfPids4DiminutivesJob[diminutiveGroupsCursor];
						fn.callDatabase(t, {"persistent_id": "^"+sGroupToFetch+"$"}, function(){
							
							setTimeout(function(){fn.unselectRowNode(t, 0);}, 500);
							});
						}
					else
						{
						fn.message("Let op", "U heeft de laatste groep bereikt");
						}
					
				}
				
			},
			
			"button_2": {
				
				"name": "Zoek/maak lemma",
				"bgcolor": "#F8E0E6",
				"textcolor": "black",
				"click": function(t){
					
					var nRow = fn.getFirstSelectedRowNodeFrom(t);
					if (nRow == null)
						nRow = fn.getActiveRowNode(t);
					
					
					var sLem = fn.getDataFromCellInRowNode(nRow, "nieuw_lem");
					if (sLem == '')
						sLem = fn.getDataFromCellInRowNode(nRow, "wordform");  // wordform is closest form to diminutive in this context
					var sWdb = fn.getDataFromCellInRowNode(nRow, "wdb");
					
					fn.prompt(["Lemma", "Voer het gezochte lemma in"], ["Vorm"], [sLem], 
							function(){	
						
								var sNewDiminutive = fn.getPromptBoxInput("Vorm");								
								
								
								// function for building a new lemma and linking it to the current attestation
								
								var buildDiminutiveLemmaAndLinkIt = function(bProcessAllRows){
									
									// default persistent id is: GH + date + dot + random number in range [0-999]
									// (eg. GH20160401144225.432)
									var sDefaultPersistentId = 
										"GH"+ fn.getCurrentTimestamp("YYYYMMDD.HHMISS") + 
										"." + Math.floor(Math.random() * 1000);
									
									// ask the user to compose a new lemma
									
									// new lemma!
									if ( !$.endsWith(sWdb, 'n'))
										sWdb = sWdb + "n";
									
									fn.prompt("Nieuw lemma", 
											["modern_lemma", "part_of_speech", "persistent_id", "wdb"], 
											[sNewDiminutive, "NOU-C", sDefaultPersistentId, sWdb], function(){
										
												var sLemma =		fn.getPromptBoxInput("modern_lemma") ;
												var sPos =			fn.getPromptBoxInput("part_of_speech") ;
												var sPersistentId =	fn.getPromptBoxInput("persistent_id") ;
												var sWdb =			fn.getPromptBoxInput("wdb") ;
												
												if (sWdb == 'WNT' && (
													!$.startsWith(sPersistentId, "M") &&
													!$.startsWith(sPersistentId, "A") &&
													!$.startsWith(sPersistentId, "S")
												)){
													fn.message("Let op", sPersistentId+" is geen toegestane PID.<BR><BR>WNT PIDs beginnen met M, A of S");
												}
												else {

													// build the new lemma
													
													fn.callFunction("api.create_new_lemma_and_get_id", 
															[sLemma, sPos, sPersistentId, sWdb], 
															function(response){
														
																var sLemId = response["create_new_lemma_and_get_id"];
																
																
																
																// As soon as the lemma is built, 
																// assign wordforms to it
																
																var aSelectedRows = fn.getAllRowNodes(t);
																
																// if we are not supposed to process all rows, but only the
																// ones which have highlight, select those rows!
																
																if (!bProcessAllRows)
																	aSelectedRows = fn.getSelectedRowNodesFrom(t);
																
																
																
																$(aSelectedRows).each(function(){
																	
																	var thisRow = this;
																	
																	
																	var bIsLastRow = fn.isLastNodeOf(thisRow, aSelectedRows);
																	var oneAwfId = fn.getDataFromCellInRowNode(thisRow, "analyzed_wordform_id");
																	
																		fn.callFunction("api.replace_analyzed_wordform", [oneAwfId, sLemId, null], function(){
																		
																			fn.updateDatabaseGivenANode(thisRow, 
																				{
																				"nieuw_lem": sLemma,
																				"nieuw_lem_id": sLemId,
																				"nieuw_pid": sPersistentId,
																				"nieuw_pos": sPos,
																				"nieuw_wdb": sWdb, 
																				"goedgekeurd": true
																				},
																				function(){
																					
																					if (bIsLastRow)
																						{
																						// refresh and look up the modified paradim!
																						
																						fn.refreshTable(t);
																						fn.callDatabase("lemmata_and_paradigma", 
																								{"lemma_id": sLemId},
																								function(){
																									fn.resetAllFilters("lemmata_and_paradigma", true); // otherwise next call might fail
																								});
																						}
																					
																				});
																		
																		});
																	
																	
																});
																
																
													});
													
												}
										
									});
									
								};
								
								// check if lemma exists
								
								fn.callFunction("api.search_for_other_lemma", [sNewDiminutive, 0, sWdb], function(response){
									
									// the found lemmata are given in a ^^^-separated string
									
									var foundLemmata = response["search_for_other_lemma"];
									var foundLemmataArr = foundLemmata.split("^^^");
									
									if (foundLemmataArr[0] == '')
										{
										fn.confirm("Lemma ontbreekt", "Er is geen ander lemma met deze vorm in het "+sWdb+".<br>Wilt u het lemma aanmaken?", 
												function(){
											
											
												var aAllRows = fn.getAllRowNodes(t);
												var aSelectedRows = fn.getSelectedRowNodesFrom(t);
												
												// in some cases, we can do the assignment right away....
												
												if ( // no selection at all means no distinction, so process all rows!
													 ( aSelectedRows == null )  
														||
													 // if we have only one row, the job can only be about that single row = so process all rows!
													 ( aAllRows != null && (fn.getAllRowNodes(t)).length == 1 )
														||
													 // if all rows are selected, once again: so process all rows!
													 ( aAllRows != null && aSelectedRows != null && aAllRows.length == aSelectedRows.length )
													)
													{
													buildDiminutiveLemmaAndLinkIt(true);
													}
												
												// but sometimes we can't: if we have more rows, and those are not all selected,
												// ask the user if we must process all of those or only the selection, just to play safe!
												else
													{
													fn.promptSelect(
															["OK", "Wilt u het aangemaakte lemma toekennen..."], 
															["aan alle woordvormen", "aan de geselecteerde woordvorm(en)"], 
															[], 
															function(response){
																if (response == 'aan alle woordvormen')
																	buildDiminutiveLemmaAndLinkIt(true);
																else
																	buildDiminutiveLemmaAndLinkIt(false);
															}, 
															function(){
																fn.message("OK", "Bewerking door gebruiker geannuleerd");
															}, 
															true);
													}
													
													
												},
												function(){
													fn.message("OK", "Bewerking door gebruiker geannuleerd");
												});
										
										}
									else
										{
										
										fn.callDatabase("lemmata_and_paradigma", 
												{"modern_lemma": "^"+sNewDiminutive+"$", "wdb": sWdb+"n?"},	// 'n?' needed otherwise lemma might not be found
												function(){
													fn.resetAllFilters("lemmata_and_paradigma", true); // otherwise next call might fail
												});
										}
									
								});
						
							}, 
							function(){
								fn.message("OK", "Operatie door gebruiker geannuleerd");
							});
					
					
				}
				
			},
			
			"button_3": {
				
				"name": "Linken!",
				"bgcolor": "green",
				"click": function(t){
					
					// there are 2 possibilities:
					//
					// [1] we already have a lemma proposal and we accept it
					// [2] we found a possible lemma in the paradigm table and accept it
					
					
					
					// functions for the job
					
					var fnConfirmPreAssignedLemma = function(t){
						
						var nFirstSelectedRow = fn.getFirstSelectedRowNodeFrom(t);					
						if (nFirstSelectedRow == null)
							nFirstSelectedRow = fn.getActiveRowNode(t);
						
						// get the current row, which is good enough since the whole screen is about the same lemma!
						
						var sLemId = fn.getDataFromCellInRowNode(nFirstSelectedRow, "nieuw_lem_id");
						
						
						var aSelectedRows = fn.getAllRowNodes(t);
						if (fn.rowsSelectionIsAllowed(t))
							aSelectedRows = fn.getSelectedRowNodesFrom(t);	
						
						
						$(aSelectedRows).each(function(){
							
							var thisRow = this;
							var bIsLastRow = fn.isLastNodeOf(thisRow, aSelectedRows);
							var oneAwfId = fn.getDataFromCellInRowNode(thisRow, "analyzed_wordform_id");
							
							// validated row can't be reprocessed (not supported in this implementation)
							
							if (fn.getDataFromCellInRowNode(thisRow, "goedgekeurd") != 't')
								{
								fn.callFunction("api.replace_analyzed_wordform", [oneAwfId, sLemId, null], function(){
									
									fn.updateDatabaseGivenANode(thisRow, 
											{
											"goedgekeurd": true
											},
											function(){
												
												if (bIsLastRow)
													{
													// refresh and look up the modified paradim!
													
													fn.refreshTable(t);														
													fn.callDatabase("lemmata_and_paradigma", 
															{"lemma_id": "^"+sLemId+"$"}, 
															function(){
																fn.resetAllFilters("lemmata_and_paradigma", true); // otherwise next call might fail
															});  
													}
												
											});
									
									});
								}
							else
								{
								if (bIsLastRow)
									fn.refreshTable(t);
								}
								
							
							
							});
					};
					
					
					var fnLinkToSelectedLemma = function(t){
						
						// get the current row of the lemmata we selected in the paradigm view
						
						var nRow = fn.getFirstSelectedRowNodeFrom("lemmata_and_paradigma");
						if (nRow == null)
							nRow = (fn.getAllRowNodes("lemmata_and_paradigma"))[0];
						
						if (nRow != null)
							{
							var sLemma = fn.getDataFromCellInRowNode(nRow, "modern_lemma");
							
							var sLemId = fn.getDataFromCellInRowNode(nRow, "lemma_id");
							if (sLemId == '') sLemId = null;
												
							// get all details about lemma
							
							var sMultiLemId = fn.getDataFromCellInRowNode(nRow, "multiple_lemmata_analysis_id");
							if (sMultiLemId == '') sMultiLemId = null;
							
							var sPersistentId = fn.getDataFromCellInRowNode(nRow, "persistent_id");
							var sPos = fn.getDataFromCellInRowNode(nRow, "lemma_part_of_speech");
							var sWdb = fn.getDataFromCellInRowNode(nRow, "wdb");
																		
							// do the assignment
							
							var aSelectedRows = fn.getAllRowNodes(t);
							if (fn.rowsSelectionIsAllowed(t))
								aSelectedRows = fn.getSelectedRowNodesFrom(t);	
							
							$(aSelectedRows).each(function(){
								
								var thisRow = this;
								var bIsLastRow = fn.isLastNodeOf(thisRow, aSelectedRows);
								var oneAwfId = fn.getDataFromCellInRowNode(thisRow, "analyzed_wordform_id");
								
								
								// validated row can't be reprocessed (not supported in this implementation)
								
								if (fn.getDataFromCellInRowNode(thisRow, "goedgekeurd") != 't')
									{
									fn.callFunction("api.replace_analyzed_wordform", [oneAwfId, sLemId, sMultiLemId], function(){
									
										fn.updateDatabaseGivenANode(thisRow, 
												{
												"nieuw_lem": sLemma,
												"nieuw_lem_id": sLemId,
												"nieuw_pid": sPersistentId,
												"nieuw_pos": sPos,
												"nieuw_wdb": sWdb, 
												"goedgekeurd": true
												},
												function(){
													if (bIsLastRow)
														{
														// refresh and look up the modified paradim!
														
														fn.refreshTable(t);													
														fn.callDatabase("lemmata_and_paradigma", 
																{"lemma_id": "^"+sLemId+"$"}, 
																function(){
																	fn.resetAllFilters("lemmata_and_paradigma", true); // otherwise next call might fail
																}); 
														}
													  
												});
									
										});
									}
								
								});
							}
						else
							{
							fn.message("Let op!", "U moet wel een rij in 'lemmata_and_paradigma' selecteren");
							}
					};

					
					// possible situations:
					//
					// 0. we have no pre-assigned lemma and no alternative lemma selected: we can't do anything
					// 1. we have a pre-assigned lemma, and no alternative lemma selected: confirm the pre-assigned lemma
					// 2. we have no pre-assigned lemma, but some alternative is selected: assign the selected alternative lemma
					// 3. we have both a pre-assigned lemma and a selected alternative lemma:
					// 3a. if the pid's are the same, just confirm the pre-assigned lemma
					// 3b. if those have different pid's: ask the user to make a choice
					
					
					var nFirstSelectedRow = fn.getFirstSelectedRowNodeFrom(t);					
					if (nFirstSelectedRow == null)
						nFirstSelectedRow = fn.getActiveRowNode(t);
					
					var sLemma = 	fn.getDataFromCellInRowNode(nFirstSelectedRow, "nieuw_lem");
					var sLemmaPid =	fn.getDataFromCellInRowNode(nFirstSelectedRow, "nieuw_pid");
					
					var nRow = fn.getFirstSelectedRowNodeFrom("lemmata_and_paradigma");
					if (nRow == null)
						nRow = (fn.getAllRowNodes("lemmata_and_paradigma"))[0];
					var sAlternativeLemma = (nRow != null) ? fn.getDataFromCellInRowNode(nRow, "modern_lemma") : "";
					var sAlternativeLemPid = (nRow != null) ? fn.getDataFromCellInRowNode(nRow, "persistent_id") : "";
					
					
					// case 0
					
					if ( sLemma == '' && nRow == null)
						{
						fn.message("Let op", "Er valt niets te linken. Kies een lemma in 'lemmata_and_paradigma' om mee te linken!");
						}
					
					// case 1
					
					else if (sLemma != '' && !fn.tableExists("lemmata_and_paradigma") ) 
						{
						fnConfirmPreAssignedLemma(t);
						}
					
					// case 2
					
					else if (sLemma == '' && nRow != null)
						{
						fnLinkToSelectedLemma(t);
						}
					
					// case 3a
					
					else if (sLemma != '' && (nRow != null && sLemmaPid == sAlternativeLemPid) )
						{
						fnConfirmPreAssignedLemma(t);
						}
					
					// case 3b
					
					else if (sLemma != '' && (nRow != null && sLemmaPid != sAlternativeLemPid) )
						{
						
						
						var sChoice1 = "Het reeds toegekende lemma bevestigen: "+sLemma+" / "+sLemmaPid;
						var sChoice2 = "Het hieronder geselecteerde lemma toekennen: "+sAlternativeLemma+" / "+sAlternativeLemPid;
						
						var aAllOptions = [sChoice1, sChoice2];
						
						fn.promptSelect(["Maak een keuze", "Waar wilt u mee linken?"], aAllOptions, null, 
								function(resp){
									
									// [1] we already have a lemma proposal (in 'nieuw_lem' field)
									//     and we accept it
									
									if (resp == sChoice1)
										{
										fnConfirmPreAssignedLemma(t);								
										}
									
									// [2] we found a possible lemma in the paradigm table 
									//     and accept it
									
									else if (resp == sChoice2)
										{
										fnLinkToSelectedLemma(t);		
										}
							
								}, 
								function(){
									fn.message("OK", "Operatie door gebruiker geannuleerd");
								}, 
								true
							);
						}
					
				}
			},
			
			"button_4": {
				
				"name": "Schoonvegen",
				"bgcolor": "yellow",
				"textcolor": "red",
				"click": function(t){
					
					var aSelection = fn.getSelectedRowNodesFrom(t);
					$(aSelection).each(function(){
						
						nCurrentRow = this;
						bIsLastRow = fn.isLastNodeOf(nCurrentRow, aSelection);
						
						// not allowed to undo, because not supported technically in this case 
						
						if (fn.getDataFromCellInRowNode(nCurrentRow, "goedgekeurd") != 't')
							{
							fn.updateDatabaseGivenANode(nCurrentRow, {
								"nieuw_lem": "",
								"nieuw_lem_id": "",
								"nieuw_pid": "",
								"nieuw_pos": "",
								"nieuw_wdb": "",
								"goedgekeurd": false
								}, function(){
									if (bIsLastRow)
										fn.refreshTable(t);
								});
							}
						else
							{
							if (bIsLastRow)
								fn.refreshTable(t);
							}
						
					});
					
					
				}
			}
			
			
		}
		
		
};


// configuration at column level
oTableConfigurationList = {
		
		"lemma_to_variants": {

			"lemma_id": {
				"click": function(t, nCell){
					var iLemId = fn.getDataFromCellNode(nCell);
					fn.callDatabase("lemmata", {"lemma_id": iLemId}, function(){
						fn.callDatabase("lemmata_and_paradigma", {"lemma_id": iLemId});
					});
				}
			},

			"lemma_variant": {
				"editable": true,
				"editcallback": function(t, n){
					fn.refreshTable(t);
				}
			},
			"main_variant": {
				"editable": true,
				"editcallback": function(t, n){
					var iLemmaId = fn.getDataFromSiblingNode(n, "lemma_id");
					var aRow = fn.getAllRowNodesWhere(t, {"lemma_id": iLemmaId});
					$(aRow).each(function(){
						var nRow = this;
						fn.callRecord(nRow, ["modern_lemma", "lemma_variant", "main_variant", "multiple"], function(){
							
							$(nRow).find("td").eq( fn.getVisibleColumnNumberOf(t, "multiple") ).find("input").attr("disabled", "disabled");
						});
					});
				}
			},
			"opmerking": {
				"editable": true,
				"editcallback": function(t, n){
					fn.refreshTable(t);
				}
			},
			"id": {
				"visible": false
			}
		},
		
		
		quotation_section_id_of_token_attestations_with_clitics: {
			
			"id": {
				"visible": false
			}
		},
		
		lemmata_without_paradigm: {
			
			"ne_label": {
				"visible": false
			},
			"portmanteau_lemma_id": {
				"visible": false
			},
			"language_id": {
				"visible": false
			},
			"is_multiple": {
				"visible": false
			},
			"quotation_section_id": {
				"bgcolor": "#F8E0E6",
				"click": function(t, nCell){
					var sQuoteId = fn.getDataFromCellNode(nCell);
					fn.callDatabase("token_attestations_worktable", {"quotation_section_id": "\"exact:"+sQuoteId+"\""});
				}
			},
			"persistent_id": {
				
				"bgcolor": "#F8E0E6",
				"click": function(t, nCell){
					var sPid = fn.getDataFromCellNode(nCell);
					var sWdb = fn.getDataFromSiblingNode(nCell, "wdb");
					
					
					if ( $.startsWith(sPid, "GH") )
						{
						fn.callDatabase("lemmata_and_paradigma", {"persistent_id": "^"+sPid+"$"});
						}
					else
						{
						window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+sPid);	
						}
					
					
					
				}
			},
			"opmerking": {
				"bgcolor": "#F8E0E6",
				"editable": true
			},
			
			"short_pid": {
				"visible": false
			},
			
			"multiple_lemmata_analysis_id": {
				"width": "30px",
				"nice_name": "mla_id",
				"bgcolor": "#F8E0E6",
				"click": function(t, nCell){
					var sMultiLemId = fn.getDataFromCellNode(nCell);
					fn.callDatabase("multilemmata", {"multiple_lemmata_analysis_id": "\"exact:"+sMultiLemId+"\""});
				}
			},
			
		},
		
		possible_groups: {
			
			"klaar": {
				"editable": true
			},
			
			"attestation_ids": {
				"visible": false
			},
			"onsetoffset": {
				"visible": false
			},
			"wordforms_arr": {
				"visible": false
			},
			"wordform": {
				"visible": false
			},
			"true_count": {
				"visible": false
			},
			"lemma_id": {
				"visible": false
			},
			"multiple_lemmata_analysis_id": {
				"visible": false
			},
			"levenshtein_dist": {
				"visible": false
			},
			
			"opmerking": {
				"editable": true
			},
			
			"quotation_section_id": {
				"click": function(t, n){
					var qId = fn.getDataFromCellNode(n);
					fn.callDatabase("token_attestations_worktable", {"quotation_section_id": "\"exact:"+qId+"\""});
				}
			},
			
			"group_id": {
				"click": function(t, n){
					
					var rowId = fn.getDataFromSiblingNode(n, "id");
					
					fn.confirm("Let op", "Aan deze citaat zal nu een group_id worden toegekend. Weet u het zeker?", 
						function(){
							fn.showProcessingMsg(t);
							fn.closeDialog();
							fn.message("OK", "Bezig...");
							
							setTimeout(function(){
								
								fn.callFunction("assign_group_id", [rowId], function(){
									fn.refreshTable(t, function(){				
										
										setTimeout(function(){
											var nRow = fn.getRowNodeWhere(t, {"id": rowId});
											var iGroupId = fn.getDataFromCellInRowNode(nRow, "group_id");
											fn.closeDialog();
											fn.removeProcessingMsg(t);
											
											fn.callDatabase("token_attestations_worktable", {"group_id": iGroupId});
										}, 500);
																			
										});
									
									});
								
							}, 200);
							
							
						}, 
						function(){
							// do nothing
						});
				}
			}
			
		},

		wordforms_to_diminutives: {
			
			"id": {
				"visible": false
			},
			
			"persistent_id": {
				
				"cell_tooltip": "Klik hier om dit lemma in GTB op te zoeken",
				
				"click": function(t, nCell){
					var sPid = fn.getDataFromCellNode(nCell);
					var sWdb = fn.getDataFromSiblingNode(nCell, "wdb");
					
					window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+sPid);
					
				}
			},
			
			"analyzed_wordform_id": {
				
				"click": function(t, n){
					
					var sAwfId = fn.getDataFromCellNode(n);
					fn.callDatabase("token_attestations_worktable", {"analyzed_wordform_ids_arr": sAwfId});
					
				}
				
			},
			
			"diminutive_str": {
				"visible": false
			},
			
			"nieuw_lem_id": {
				
				"cell_tooltip": "Klik hier om dit lemma in HiLex op te zoeken",
				
				"click": function(t, nCell){
					var sId = fn.getDataFromCellNode(nCell);
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sId},
						function(){
							fn.resetAllFilters("lemmata_and_paradigma", true); // otherwise next call might fail
						});
				}
			},
			
			"nieuw_pid": {
				
				"cell_tooltip": "Klik hier om dit lemma in GTB op te zoeken",
				
				"click": function(t, nCell){
					var sPid = fn.getDataFromCellNode(nCell);
					var sWdb = fn.getDataFromSiblingNode(nCell, "nieuw_wdb");
					
					window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+sPid);
					
				}
			},
			
			"nieuw_lem": {
				
				"bgcolor": "#F8E0E6" 
					
			},
			
			"opmerking": {
				"editable": true
			}
			
		},
		
		missing_mnw_quotes_in_hilex: {
			
			"eg_id": {
				
				"click": function(t, n){
					
					var sQuoteId = fn.getDataFromCellNode(n);
					var sLemId = sQuoteId.replace(/^(c)(\d+)(_)(\d+)$/, '$2');
					
					window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb=MNW&id="+sLemId+"&Citaat_id="+sQuoteId);					
					
					fn.callDatabase("lemmata_and_paradigma", {"persistent_id": "^"+sLemId+"$"}, function(){
						fn.callDatabase("token_attestations_worktable", {"quotation_section_id": "^"+sQuoteId+"$"});
					});
				}
				
			},
			
			"opmerking": {
				"editable": true
			}
		},
		
		mnw_lemma_parts_of_speech:{
			
			"id": {
				"visible": false
			},
			"mnw_lemma_pos": {
				"click": function(t,n){
					var sPos = fn.escapeRegexChars( fn.getDataFromCellNode(n) );
					fn.callDatabase("lemmata", {"lemma_part_of_speech": "^"+sPos+"$"});
				}
			},
			"correction_pos": {
				"editable": true
			}
		},
		
		mnw_wordforms_parts_of_speech:{
			
			"id": {
				"visible": false
			},
			"mnw_wordform_pos": {
				"click": function(t,n){
					var sPos = fn.escapeRegexChars( fn.getDataFromCellNode(n) );
					fn.callDatabase("lemmata_and_paradigma", {"part_of_speech": "^"+sPos+"$"});
				}
			},
			"correction_pos": {
				"editable": true
			}
		},

		ontbrekende_citaten: {
			"opmerking": {
				
				"editable": true
			}
		},
		
		double_quotations_id_to_check: {
			
			"quotation_section_id": {
				"click": function(t, n){
					
					var sVal = fn.getDataFromCellNode(n);
					fn.callDatabase("token_attestations_worktable", {"quotation_section_id": "exact:"+sVal});
				}
			},
			"verwerkt": {
				"editable": true
			}
		},

		
		modified_lemmata_view: {
			
		}, 
		
		modified_paradigm_view: {
			
		},
		
		lemmata: {
			
			"lemma_id": {
				"width": "30px",
				"click": function(t, nCell){
					var sLemId = fn.getDataFromCellNode(nCell);
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemId});
				}
			},

			"lemma_variants": {

				"click": function(t, nCell){

					var fnVariantMenu = function(){

						// get the lemma-id
						// and ask the database to give all available variants

						var iLemmaId = fn.getDataFromSiblingNode(nCell, "lemma_id");
						var sWdb = fn.getDataFromSiblingNode(nCell, "wdb");

						fn.callFunction("api.get_variants_of_lemma", [iLemmaId], function(resp){

							// parse response
							var sLemAndVariants = resp["get_variants_of_lemma"];
							var aLemAndVariants = sLemAndVariants.split("###");
							
							// main lemma string
							var sLemma = aLemAndVariants[0];
							// variants
							var aVariants = aLemAndVariants.length > 1 ?
								(aLemAndVariants[1]).split(", ")
								:
								(fn.getDataFromSiblingNode(nCell, "modern_lemma")).split(", ");

							// if lemma contains no commas, we do a chosen main lemma already
							// otherwise consider we have none 
							var aAlreadyChosen = sLemma.indexOf(",")>-1 ? [] : [sLemma];

							// add options for adding variants
							var sAddVariantLabel = "Voeg een variant toe";
							var aAllOptions = aVariants.concat( [null, sAddVariantLabel] );


							// gather the main lemma (modern_lemma) and the variant lemma strings
							// and show those in a list, allowing the user to choose the main variant out of those.
							
							fn.promptSelect(["Kies de hoofdvariant", "Kies de hoofdvariant (of SHIFT+Klik om variant te verwijderen):"], aAllOptions, aAlreadyChosen, 
								function(aChosen){

									var toets = kf._getPressedKey();

									if (aChosen.length != 1){
										fn.message("Let op", "U moet één hoofdvariant kiezen uit de lijst!");
									}
									else {
										fn.message("Even geduld", "HiLex werkt nu alle verwijzingen naar dit lemma bij. Een ogenblikje...");

										if (toets == "shift"){
											
											fn.removeFromDatabaseGivenFieldValues("lemma_to_variants", {"lemma_id": iLemmaId, "lemma_variant": aChosen[0]},
												function(){
													fn.callRecord(fn.getRowNode(nCell), ["modern_lemma", "lemma_variants"], function(){
														fn.closeDialog();
														if (fn.tableExists("lemmata_and_paradigma")){
															fn.refreshTable("lemmata_and_paradigma");
														}
														if (fn.tableExists("lemma_to_variants")){
															fn.refreshTable("lemma_to_variants");
														}
												});
											});

										}
										else {

											fn.updateDatabaseGivenFieldValues("lemma_to_variants", 
												{"lemma_id": iLemmaId, "lemma_variant": "^"+aChosen[0]+"$"}, 
												{"main_variant": true}, 
												function(){
													fn.callRecord(fn.getRowNode(nCell), ["modern_lemma", "lemma_variants"], function(){
														fn.closeDialog();
														if (fn.tableExists("lemmata_and_paradigma")){
															fn.refreshTable("lemmata_and_paradigma");
														}
														if (fn.tableExists("lemma_to_variants")){
															fn.refreshTable("lemma_to_variants");
														}
													});
												}
											);

										}

										
										
									}
								}, 
								function(){
									// cancel
									fn.refreshTable(t);
								},
								function(sChosenItem){

									// user chooses to add variant
									if (sChosenItem == sAddVariantLabel){
										
										fn.closeDialog();
										fn.prompt(
											["Voeg nieuwe variant toe", "Voer één of meer nieuwe varianten. Indien nodig, gebruik een komma als scheidingsteken"], 
											["Varianten"], 
											[sLemma], 
											function(resp){
												
												fn.showProcessingMsg(t);
												var aNewVariants = (setCommasRight(resp["Varianten"])).split(", ");

												for (var i=0; i<aNewVariants.length; i++){

													fn.insertIntoDatabase("lemma_to_variants", {"lemma_id": iLemmaId, "wdb": sWdb, "modern_lemma": sLemma, "lemma_variant": aNewVariants[i]}, 
														function(){
															// return to the variant main menu 
															if (i == aNewVariants.length-1){

																fn.removeProcessingMsg(t);
																// recall the menu
																setTimeout(function(){fnVariantMenu();}, 500);
															}
															
														}
													); // end of insert


												}

											} // end of prompt callback
										);

										
									}
									// user has chosen a pre-existing variant to be the main one
									else {

										// trigger click on OK
										$( "#dialog_accept_button" ).click();
									}

									

								});
						});

					};

					fnVariantMenu();

				} // end of click event	

			},
			
			"modern_lemma": {
				"colsort": "asc",
				"editable": true,
				"editcallback": function(t, n, value){
					
					var sLemmaId = fn.getDataFromSiblingNode(n, "lemma_id");

					// check if we had multiple (comma separated) variants first, 
					// but only one after edition
					var oldValue = n.revert.trim();
					if (oldValue.indexOf(",")>0	// old value contained commas
						&&
						value.indexOf(",")<0	// commas are gone
						){
							
							fn.updateDatabaseGivenFieldValues("lemma_to_variants", {"lemma_id": sLemmaId, "lemma_variant": "^"+value.trim()+"$"}, {"main_variant": true}, function(){

								setTimeout(function(){
									fn.removeFromDatabaseGivenFieldValues("lemma_to_variants", {"lemma_id": sLemmaId, "main_variant": false}, function(){
																					
										if (fn.tableExists("lemma_to_variants")){
											fn.refreshTable("lemma_to_variants");
										}																		
										
									});

								}, 100);	
									
							});

					}
					else {
						fn.refreshTable(t, function(){
						
							// small delay otherwise it won't work
							$("#"+fn.getTableName(t)).delay(500).queue(function(){

								if ( !isNaN(sLemmaId) )
									{
									fn.callDatabase("token_attestations_worktable", {"lemma_id": sLemmaId});
									}						

								$(this).dequeue();
							});						
						});

					}
					
				}
			},
			"lemma_part_of_speech": {
				"width": "30px",
				"nice_name": "lemma_pos",
				"editable": true,
				"editcallback": function(t, n, value){

					var oRow = 		fx.getFirstSelectedRowFrom(t);
					var sLemmaId =	fx.getDataFromCellInRow(oRow, "lemma_id");
					
					fn.refreshTable(t, function(){
						
						// small delay otherwise it won't work
						$("#"+fn.getTableName(t)).delay(500).queue(function(){

							if ( !isNaN(sLemmaId) )
								{
								fn.callDatabase("token_attestations_worktable", {"lemma_id": sLemmaId});
								}						

							$(this).dequeue();
						});
					});
				}
			},
			"persistent_id": {
				"click": function(t, n){
					
					var oCell = 		fx.getCell(n);
					var sWdb = 			fx.getDataFromSiblingCell(oCell, "wdb");
					var iPersistentId =	fx.getDataFromCell(oCell);
					
					// remove illegal string parts, which would cause an error in the GTB 
					sWdb = sWdb.replace("_DIM", "");
					
					window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+iPersistentId);
					
				}
			},
			
			"opmerking":{
				"editable": true
			},
			
			"online": {
				"editable": true				
			},
			"portmanteau_lemma_id": {
				"nice_name": "portm_lem_id"
			},
			"language_id": {
				"nice_name": "lang_id"
			},
			"super_lem_id": {
				"width": "30px",
				"nice_name": "suplem_id"
			},
			"multi_part":{
				"width": "30px"
			}


		},
		
		"thomas_new_fabulous_table": {
			"id": {
				"visible": false
			},
			"opmerking": {
				"editable": true
			},
			"opgelost": {
				"editable": true
			},

			"simplex": {
				"click": function(t, n){
					var sLemId = fn.getDataFromSiblingNode(n, "lemma_id")
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemId});
				}
			},

			"complex": {
				"click": function(t, n){
					var sMultiLemId = fn.getDataFromSiblingNode(n, "multiple_lemmata_analysis_id");
					fn.callDatabase("lemmata_and_paradigma", {"multiple_lemmata_analysis_id": sMultiLemId});
				}
			},

			"lemma_id": {
				"click": function(t, n){
					var sLemId = fn.getDataFromCellNode(n);
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemId});
				}
			},
			"multiple_lemmata_analysis_id": {
				"click": function(t, n){
					var sMultiLemId = fn.getDataFromCellNode(n);
					fn.callDatabase("lemmata_and_paradigma", {"multiple_lemmata_analysis_id": sMultiLemId});
				}
			}
		},

		"thomas_new_fabulous_table_premium": {
			"id": {
				"visible": false
			},
			"opmerking": {
				"editable": true
			},
			"opgelost": {
				"editable": true
			},

			"simplex": {
				"click": function(t, n){
					var sLemId = fn.getDataFromSiblingNode(n, "lemma_id")
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemId});
				}
			},

			"complex": {
				"click": function(t, n){
					var sMultiLemId = fn.getDataFromSiblingNode(n, "multiple_lemmata_analysis_id");
					fn.callDatabase("lemmata_and_paradigma", {"multiple_lemmata_analysis_id": sMultiLemId});
				}
			},

			"lemma_id": {
				"click": function(t, n){
					var sLemId = fn.getDataFromCellNode(n);
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemId});
				}
			},
			"multiple_lemmata_analysis_id": {
				"click": function(t, n){
					var sMultiLemId = fn.getDataFromCellNode(n);
					fn.callDatabase("lemmata_and_paradigma", {"multiple_lemmata_analysis_id": sMultiLemId});
				}
			}
		},


		lemmata_and_paradigma: {
			
			"super_lem_id" :{
				"nice_name": "suplem_id",
				"width": "30px"
			},
			
			"wdb": {
				"choosefrom": ["", "ONW", "ONWn", "ONW|ONWn", "VMNW", "VMNWn", "VMNW|VMNWn", "MNW", "MNWn", "MNW|MNWn", "WNT", "WNTn", "WNT|WNTn"]
			},
			
			"full_analysis": {
				"width": "30px"
			},
			"modern_lemma": {
				"width": "30px",		
				"editable": true,
				"editcallback": function(t, n, value){

					var sLemmaId = fn.getDataFromSiblingNode(n, "lemma_id");

					// check if we had multiple (comma separated) variants first, 
					// but only one after edition
					var oldValue = n.revert.trim();

					if (oldValue.indexOf(",")>0	// old value contained commas
						&&
						value.indexOf(",")<0	// commas are gone
						){					

							fn.updateDatabaseGivenFieldValues("lemma_to_variants", {"lemma_id": sLemmaId, "lemma_variant": "^"+value.trim()+"$"}, {"main_variant": true}, function(){

								setTimeout(function(){
									fn.removeFromDatabaseGivenFieldValues("lemma_to_variants", {"lemma_id": sLemmaId, "main_variant": false}, function(){
																					
										if (fn.tableExists("lemma_to_variants")){
											fn.refreshTable("lemma_to_variants");
										}																		
										
									});

								}, 100);	
									
							});
					}
					else {
						// we need a refresh to make the change visible in rest of paradigm
						// where the lemmaform is repeated
						fn.refreshTable(t);
					}
					
					// Katrien's request:
					if (fn.tableExists("token_attestations_worktable"))
						fn.refreshTable("token_attestations_worktable");
				}

			},

			"lemma_variants": {
				"width": "30px",
				"click": function(t, nCell){

					var fnVariantMenu = function(){

						// get the lemma-id
						// and ask the database to give all available variants

						var iLemmaId = fn.getDataFromSiblingNode(nCell, "lemma_id");
						var sWdb = fn.getDataFromSiblingNode(nCell, "wdb");

						fn.callFunction("api.get_variants_of_lemma", [iLemmaId], function(resp){

							// parse response
							var sLemAndVariants = resp["get_variants_of_lemma"];
							var aLemAndVariants = sLemAndVariants.split("###");
							
							// main lemma string
							var sLemma = aLemAndVariants[0];
							// variants
							var aVariants = aLemAndVariants.length > 1 ?
								(aLemAndVariants[1]).split(", ")
								:
								(fn.getDataFromSiblingNode(nCell, "modern_lemma")).split(", ");

							// if lemma contains no commas, we do a chosen main lemma already
							// otherwise consider we have none 
							var aAlreadyChosen = sLemma.indexOf(",")>-1 ? [] : [sLemma];

							// add options for adding variants
							var sAddVariantLabel = "Voeg een variant toe";
							var aAllOptions = aVariants.concat( [null, sAddVariantLabel] );


							// gather the main lemma (modern_lemma) and the variant lemma strings
							// and show those in a list, allowing the user to choose the main variant out of those.
							
							fn.promptSelect(["Kies de hoofdvariant", "Kies de hoofdvariant (of SHIFT+Klik om variant te verwijderen):"], aAllOptions, aAlreadyChosen, 
								function(aChosen){

									var toets = kf._getPressedKey();

									if (aChosen.length != 1){
										fn.message("Let op", "U moet één hoofdvariant kiezen uit de lijst!");
									}
									else {
										fn.message("Even geduld", "HiLex werkt nu alle verwijzingen naar dit lemma bij. Een ogenblikje...");

										if (toets == "shift"){
											
											fn.removeFromDatabaseGivenFieldValues("lemma_to_variants", {"lemma_id": iLemmaId, "lemma_variant": aChosen[0]},
												function(){
													fn.callRecord(fn.getRowNode(nCell), ["modern_lemma", "lemma_variants"], function(){
														fn.closeDialog();
														if (fn.tableExists("lemmata_and_paradigma")){
															fn.refreshTable("lemmata_and_paradigma");
														}
														if (fn.tableExists("lemma_to_variants")){
															fn.refreshTable("lemma_to_variants");
														}
												});
											});

										}
										else {

											fn.updateDatabaseGivenFieldValues("lemma_to_variants", 
												{"lemma_id": iLemmaId, "lemma_variant": "^"+aChosen[0]+"$"}, 
												{"main_variant": true}, 
												function(){
													fn.callRecord(fn.getRowNode(nCell), ["modern_lemma", "lemma_variants"], function(){
														fn.closeDialog();
														if (fn.tableExists("lemmata_and_paradigma")){
															fn.refreshTable("lemmata_and_paradigma");
														}
														if (fn.tableExists("lemma_to_variants")){
															fn.refreshTable("lemma_to_variants");
														}
													});
												}
											);

										}									
										
									}
								}, 
								function(){
									// cancel
									fn.refreshTable(t);
								},
								function(sChosenItem){

									// user chooses to add variant
									if (sChosenItem == sAddVariantLabel){
										
										fn.closeDialog();
										fn.prompt(
											["Voeg nieuwe variant toe", "Voer één of meer nieuwe varianten. Indien nodig, gebruik een komma als scheidingsteken"], 
											["Varianten"], 
											[sLemma], 
											function(resp){
												
												fn.showProcessingMsg(t);
												var aNewVariants = (setCommasRight(resp["Varianten"])).split(", ");

												for (var i=0; i<aNewVariants.length; i++){

													fn.insertIntoDatabase("lemma_to_variants", {"lemma_id": iLemmaId, "wdb": sWdb, "modern_lemma": sLemma, "lemma_variant": aNewVariants[i]}, 
														function(){
															// return to the variant main menu 
															if (i == aNewVariants.length-1){

																fn.removeProcessingMsg(t);
																// recall the menu
																setTimeout(function(){fnVariantMenu();}, 500);
															}
															
														}
													); // end of insert
												}

											} // end of prompt callback
										);										
									}
									// user has chosen a pre-existing variant to be the main one
									else {
										// trigger click on OK
										$( "#dialog_accept_button" ).click();
									}									

								}
								
							); // end of function
						});

					};

					fnVariantMenu();

				} // end of click event	

			},

			"persistent_id": {		
				"width": "30px",
				"cell_tooltip": "Open WDB",
				"click": function(t, n){
					
					var oCell = 		fx.getCell(n);
					var sWdb = 			fx.getDataFromSiblingCell(oCell, "wdb");
					var iPersistentId =	fx.getDataFromCell(oCell);
					
					// remove illegal string parts, which would cause an error in the GTB 
					sWdb = sWdb.replace("_DIM", "");
					
					window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+iPersistentId);					
				}
			},
			
			"multiple_lemmata_analysis_id": {
				"nice_name": "mla_id",
				"width": "30px",				
				"cell_tooltip": "Toon details",
				"click": function(t, n){
					
					var oCell = 	fx.getCell(n);
					var iMlaId =	fx.getDataFromCell(oCell);
					
					fn.callDatabase("multiple_lemmata_analyses_view", {"multiple_lemmata_analysis_id": iMlaId},
							function(){
						fn.scrollToTable("multiple_lemmata_analyses_view");
					});
					
				},
				"contextmenu": {
					"items": {
						"rebuild_multilem": { "name": "Verbouw multilemma" }
					},
					"callback": function(t, n, key, options){
						if (key == "rebuild_multilem"){

							var sMultilemId = fn.getDataFromCellNode(n);
							var sMultilem = fn.getDataFromSiblingNode(n, "modern_lemma");
							var sMultiWdb = fn.getDataFromSiblingNode(n, "wdb");

							fn.callFunction("api.get_part_lemmata_of", [sMultilemId], function(resp){

								var aResp = (resp["get_part_lemmata_of"]).split("@@@");
								var hLemmaToId = new Hashtable();
								var aLemmaList = [];
								for (var di=0; di<aResp.length; di++){
									var sLem = aResp[di].split(':::')[0];
									var sLemId = aResp[di].split(':::')[1];

									aLemmaList.push(sLem);
									hLemmaToId.put(sLem, sLemId);
								}


								// autocomplete for lemma to replace with
								$(document).on(
									"focus", 
									"#prompt_tevervangendoor", 
									function(event) {
										
										$(event.target).autocomplete({
											
											delay: 750,
											minLength: 2,
											source: function(request, response){
												
												fn.callFunction("api.get_lemmata_from_prefix", [fn.quote(request.term), fn.quote(sMultiWdb)], 
														function(func_resp){  
													
													var aSuggestionsArr = 
														(func_resp["get_lemmata_from_prefix"]).split("|");
													
													response($.map(aSuggestionsArr, function (item) {
														return {
															label: item,
															value: item
														};
													}));
												});
											},
											open: function( event, ui ) {
												$(this).autocomplete('widget').putInFront();
												return false;
											},
											select: function( event, ui ) {
												
												// nothing for now
											}
										});
										
									}
								);


								fn.prompt(["Multilemma verbouwen", "Let op! U wilt '"+sMultilem+"' verbouwen:<BR>dit multiple-lemma zal OVERAL in het lexicon worden aangepast.<BR><BR>Kies:"], 
									["te vervangen deellemma", "te vervangen door"], 
									[aLemmaList, ""], 
									function(resp){

										// get rid of autocomplete
										$(document).off("focus", "#prompt_tevervangendeellemma");

										// get id of lemma to replace
										var sLemmaToReplace = resp["te vervangen deellemma"];
										var iLemmaIdToReplace = hLemmaToId.get(sLemmaToReplace);

										// get id of lemmat to use instead
										var sLemmaToUseInstead = resp["te vervangen door"];
										var iLemmaIdToUseInstead = sLemmaToUseInstead.replace(/.+, id:(.+)\)$/, '$1');

										// now do the trick!!!
										//alert("replace "+iLemmaIdToReplace+" by "+iLemmaIdToUseInstead);
										fn.closeDialog();
										fn.message("Bezig...", "Bezig met bijwerken van het lexicon.<BR><BR>Even wachten a.u.b...");
										setTimeout(function(){

											fn.callFunction("api.replace_part_of_multilemma", [sMultilemId, iLemmaIdToReplace, iLemmaIdToUseInstead], function(resp){
												
												fn.closeDialog();
												fn.callDatabase(t, {"multiple_lemmata_analysis_id": resp["replace_part_of_multilemma"]});
											});
										}, 200);
										
									},
									function(){
										fn.closeDialog();
										fn.message("Ok", "Operatie door gebruiker geannuleerd.");
									}
								);

							});


						}
					} // end of callback
				}
			},
			
			"analyzed_wordform_id": {
				
				"width": "30px",

				"bgcolor": "#F8E0E6",
				"cell_tooltip": "Toon citaten",
				"click": function(t, n){
					
					var oCell = 	fx.getCell(n);
					var iAwfId = 	fx.getDataFromCell(oCell);
					var iLemmaId =	fx.getDataFromSiblingCell(oCell, "lemma_id");
					
					fn.callDatabase("token_attestations_worktable", 
						{"analyzed_wordform_ids_arr": "{"+iAwfId+"}", "lemma_id": iLemmaId},
						function(){
							fn.scrollToTable("token_attestations_worktable");
						});
				}
			},
			"group_id": {	
				"width": "30px",			
				"cell_tooltip": "Totaal citaten bijbehorend bij groep",
				"click": function(t, n){
					
					var oCell =		fx.getCell(n);
					var iGroupId =	fx.getDataFromCell(oCell);
					var iLemmaId =	fx.getDataFromSiblingCell(oCell, "lemma_id");
					
					fn.callDatabase("token_attestations_worktable", 
						{"group_id": iGroupId, "lemma_id": iLemmaId},
						function(){
							fn.scrollToTable("token_attestations_worktable");
						});
				}
			},
			"wordform": {

			},
			
			"lemma_part_of_speech": {
				"nice_name": "lemma_pos",
				"width": "30px",

				"editable": true,
				"editcallback": function(t, n){
					
					// we need a refresh to make the change visible in rest of paradigm
					// where the lemmaform is repeated
					fn.refreshTable(t); 
				}

			},
			"part_of_speech": {
				//"nice_name": "pos",
				//"width": "30px",
				"editable": true				
			},
			
			"online": {
				"editable": true,
				"editcallback": function(t, n, value){
					fn.refreshTable(t);
				}
			},
			
			"opmerking":{
				"editable": true
			},
			
			"notes":{
				"cell_tooltip": "Toevoegen: Klik / Verwijder: Alt+Klik",
				"click": function(t, n){
					
					var currentVal = fn.getDataFromCellNode(n);
					var nCurrentRow = fn.getRowNode(n);
					var sRecordId = fn.getRowNodeId(n);
					
					// alt pressed = remove notes
					if (kf._getPressedKey() == "alt") {
						// if there is only one note, just remove it
						if (currentVal.trim().split(" ").length == 1) {
							currentVal = ""
						}
						// but if there are more than one notes, check which one was clicked upon
						else {
							var clickedUpon = fn.getWordClickedUponInNode(nCurrentRow, "notes");
							currentVal = (currentVal.regexReplaceAll("(\\b"+clickedUpon.text+"\\b)", "").regexReplaceAll(" +", " ")).trim();
						}						
					}
					// no key pressed means: add note
					else {
						// add note only if it isn't there yet, otherwise we'll get doubles
						if ( !currentVal.match("\\b"+notesKey+"\\b") )
							currentVal += " "+notesKey;						
					}
					
					// update database with new notes, and update cell on screen
					fn.updateDatabaseGivenANode(n, {"notes": currentVal.trim()}, function(){
						
						fn.getRecord(t, sRecordId, function(resp){				
							fn.putDataIntoCellNode(nCurrentRow, "notes", resp["notes"]);
							})
						});
				}				
			},
			
			"unique_id":{
				"visible": false
			},
			"superlem": {
				"width": "30px"
			},
			"lemma_id": {
				"width": "30px"
			},
			"wordform_id": {
				"width": "30px"
			},
			"wordform": {
				"width": "30px"
			},
			"wf_online": {
				"width": "30px"
			}


		},
		
		token_attestations: {
			
			"document_id": {
				"cell_tooltip": "Toon bron",
				"click": function(t,n){
					
					var oCell =			fx.getCell(n);
					var iDocumentId =	fx.getDataFromCell(oCell);
					
					fn.callDatabase("documents", 
						{"document_id": iDocumentId}, 
						function(){
							fn.scrollToTable("documents");
						}, 
						{"viewtype": "form"});
				}
			}
		},
		
		
		marijke_spelling_giganthilex_differences: {
			
			marijke_lemma: {
				"editable": true,
				"colsort": "asc"
			},
			id: {
				"visible": false
			},
			
			persistent_id: {
				
				"click": function(t, n){
					
					var sPid = fn.getDataFromCellNode(n);
					var sWdb = fn.getDataFromSiblingNode(n, "wdb");
					fn.callDatabase("lemmata_and_paradigma", {"persistent_id": sPid, "wdb": sWdb},
						function(){
							fn.scrollToTable("lemmata_and_paradigma");
						});
				}
				
			}
		},
		
		"ticket_179_possible_doubled_lemmata": {
			
			modern_lemma: {
				"click": function(t, nCell){
					var nRow = fn.getRowNode(nCell);
					sIds = fn.getDataFromCellInRowNode(nRow, "pids");
					fn.callDatabase("lemmata", {"persistent_id": sIds});
				}
			},
			lemma_part_of_speech: {
				"click": function(t, nCell){
					var nRow = fn.getRowNode(nCell);
					sIds = fn.getDataFromCellInRowNode(nRow, "pids");
					fn.callDatabase("lemmata", {"persistent_id": sIds});
				}
			},
			wdb: {
				"click": function(t, nCell){
					var nRow = fn.getRowNode(nCell);
					sIds = fn.getDataFromCellInRowNode(nRow, "pids");
					fn.callDatabase("lemmata", {"persistent_id": sIds});

				}
			},
			lemma_ids: {
				"visible": false
			},
			pids: {
				"visible": false
			},
			opgelost: {
				"bgcolor": "#F8E0E6",
				"editable": true
			},
			opmerking: {
				"editable": true
			},
			id: {
				"visible": false
			}
		},
		
		token_attestations_worktable: {

			"notes":{
				"width": "30px",
				"cell_tooltip": "Toevoegen: Klik / Verwijder: Alt+Klik",
				"click": function(t, n){
					
					var currentVal = fn.getDataFromCellNode(n);
					var nCurrentRow = fn.getRowNode(n);
					var sRecordId = fn.getRowNodeId(n);
					
					// alt pressed = remove notes
					if (kf._getPressedKey() == "alt") {
						// if there is only one note, just remove it
						if (currentVal.trim().split(" ").length == 1) {
							currentVal = ""
						}
						// but if there are more than one notes, check which one was clicked upon
						else {
							var clickedUpon = fn.getWordClickedUponInNode(nCurrentRow, "notes");
							currentVal = (currentVal.regexReplaceAll("(\\b"+clickedUpon.text+"\\b)", "").regexReplaceAll(" +", " ")).trim();
						}						
					}
					// no key pressed means: add note
					else {
						// add note only if it isn't there yet, otherwise we'll get doubles
						if ( !currentVal.match("\\b"+taNotesKey+"\\b") )
							currentVal += " "+taNotesKey;						
					}
					
					// update database with new notes, and update cell on screen
					fn.updateDatabaseGivenANode(n, {"notes": currentVal.trim()}, function(){
						
						fn.getRecord(t, sRecordId, function(resp){				
							fn.putDataIntoCellNode(nCurrentRow, "notes", resp["notes"]);
							})
						});
				}				
			},
			
			"process_now": {
				"visible": false
			},
			
			"old_quotation_section_id": {
				"visible": false
			},
			
			"job_page": {
				
			},

			"token_previous": {
				"visible": false
			},
			"token_next": {
				"visible": false
			},
			
			"opmerking": {
				"editable": true
			},
			
			"online": {
				"editable": true
			},
            
    		"citblock_id": {
				
				"click": function(t, n){
					
					var oCell = 	fx.getCell(n);					
					var sCitBlockId =	fx.getDataFromCell(oCell);
					
					fn.callDatabase("citblock_comparison", {"xml_citblock_id": "exact:"+sCitBlockId});
				}
			},
			
			"wdb": {
				"choosefrom": ["", "ONW", "ONWn", "ONW|ONWn", "VMNW", "VMNWn", "VMNW|VMNWn", "MNW", "MNWn", "MNW|MNWn", "WNT", "WNTn", "WNT|WNTn"]
			},
			
			"quotation_section_id": {
				
				"click": function(t, n){
					
					var sQuoteSectionId =	fn.getDataFromCellNode(n);
					var sWdb = 				fn.getDataFromSiblingNode(n, "wdb");
					//var sWords = 			removeTags( fn.removeHighlight(fn.getDataFromSiblingNode(n, "wordform")) );					
					
					if (kf.isPressed("shift")) {
						
						fn.callDatabaseInNewTab(t, {"quotation_section_id": "\"exact:"+sQuoteSectionId+"\""});
					}
					else {
						// look up the right lemma PID given the current quotation_section_id
						
						fn.callFunction("api.get_online_pid_for_quote_id", [sQuoteSectionId], function(response){
							
							setTimeout(function(){
								
								var sLemmaPid = response["get_online_pid_for_quote_id"];
								
								// if we didn't manage to get a PID, extract a (very likely) valid one from the quotation_section_id
								
								if (sLemmaPid == '' || sLemmaPid == null) {
									if ( $.startsWith(sWdb, "MNW") ) {
										// MNW quotes ids are like c49737_0000
										sLemmaPid = sQuoteSectionId.substring(1, sQuoteSectionId.indexOf("_"));
									}
									else if ( $.startsWith(sWdb, "WNT") ) {
										// WNT quotes ids are like M062741.eg.11762
										sLemmaPid = sQuoteSectionId.substring(0, sQuoteSectionId.indexOf("."));
									}
								}
								
								// function for opening GTB quotes
								// http://gtb.inl.nl/iWDB/search?actie=article&wdb=WNT&id=M000145&Citaat_id=S000095.eg.257&citaat=werken&domein=2
								
								//window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+sLemmaPid+"&Citaat_id="+sQuoteSectionId+"&citaat="+sWords+"&domein=2");
								window.open("http://gtb.inl.nl/iWDB/search?actie=article&wdb="+sWdb+"&id="+sLemmaPid+"&Citaat_id="+sQuoteSectionId+"&domein=2");
								
							}, 200);							
						});
					}
					
				} // end of click
			},
			
			"quotation_section_id_was": {
				"visible": false
			},
			
			"lemma_id": {
				"click": function(t, n){
					var sLemmaId = fn.getDataFromCellNode(n);
					fn.callDatabase("lemmata_and_paradigma", {"lemma_id": sLemmaId},
							function(){
								fn.scrollToTable("lemmata_and_paradigma");
							});
				}
			},
			
			"multiple_lemmata_analysis_id": {
				"nice_name": "mla_id",
				"width": "30px",
				"click": function(t, n){
					var sMultilemId = fn.getDataFromCellNode(n);
					fn.callDatabase("lemmata_and_paradigma", {"multiple_lemmata_analysis_id": sMultilemId},
							function(){
								fn.scrollToTable("lemmata_and_paradigma");
							});
				}
			},
			
			"modern_lemma": {
				"cell_tooltip": "Toon citaten die ambiguïteit delen<BR>[Shift] String bijwerken",
				"click": function(t, n){

					if (kf.isPressed("shift")){
						var sAttId = fn.getDataFromSiblingNode(n, "attestation_ids");
						fn.callFunction("api.set_lemma_string_for_attestation_worktable", [sAttId, false], function(){

							var sOnsetoffset = fn.getDataFromSiblingNode(n, "onsetoffset");
							var sQuotSectId = removeTags(fn.getDataFromSiblingNode(n, "quotation_section_id"));
							fn.clearAllFilters(t);
							fn.callDatabase(t, {"onsetoffset": "^"+sOnsetoffset+"$", "quotation_section_id": "^"+sQuotSectId+"$"});
						});
					}
					else {
						var sOnsetoffset = fn.getDataFromSiblingNode(n, "onsetoffset");
						var sQuotSectId = removeTags(fn.getDataFromSiblingNode(n, "quotation_section_id"));
						fn.clearAllFilters(t);
						fn.callDatabase(t, {"onsetoffset": "^"+sOnsetoffset+"$", "quotation_section_id": "^"+sQuotSectId+"$"});
					}

					
				}
			},
			
			"attestation_ids": {
				"nice_name": "att_ids",
				"class": "linebrk",
				"render": function(text){
					return text.replace(/([^,]+,[^,]+,[^,]+,)/g, '$1 ');
				},
				"visible": false
			},

			"onsetoffset": {
				"visible": false
			},
			"wordform": {
				"class": "linebrk_wf",
				"render": function(text){
					return text.replace(/([^,]+,[^,]+,[^,]+,)/g, '$1 ');
				},
				"visible": false
			},
			// column wordform_alphabetic is used by a database for comparing a newly manually built attestation
			// with pre-existing attestation of the same lemma, so as to be able to decide wether a new set of
			// analyzed wordforms needs to be constructed or not.
			"wordform_alphabetic": {
				"visible": false
			},
			"analyzed_wordform_ids": {
				"visible": false
			},
			"analyzed_wordform_ids_arr": {
				"visible": false
			},
			"group_id": {
				"visible": false
			},
			"derivation_ids": {
				"visible": false
			},
			"document_id": {
				"cell_tooltip": "Toon bron",
				"click": function(t, n){
					
					var oCell =			fx.getCell(n);
					var iDocumentId =	fx.getDataFromCell(oCell);
					
					fn.callDatabase("documents", {"document_id": iDocumentId}, 
							function(){
								fn.scrollToTable("documents");
							}, 
							{"viewtype": "form"});
				}
			},
			"doorvoeren": {
				
				"sortable": false,
				"button": "Doorvoeren",
				"button_tooltip": "Gewijzigde attestatie verwerken in het lexicon",
				"click": function(t, n){
					
					fn.confirm("Attestatie verwerken", 
							"Weet u zeker dat u de gewijzigde attestatie nu in het lexicon wilt verwerken? "+
							"<br><br>" +
							"(Doe dit pas als in de citaat de correcte tokens geselecteerd zijn)", 
					
						function(){
						
							$(n).find("button").hide();
					
							fn.showProcessingMsg(t);
					
					
							// Some words have been selected manually in the quote, causing new
							// onsets and offsets to be saved into the onsetoffset column.
							//
							// Now the 'Doorvoeren' button has been clicked on,
							// we need to rebuild the other fields content accordingly:
												
							// [1] in a first step we gather the highlight wordforms
							//     and put those in the same order as the their onsets (=keep relation!) 
													
							var sNewWordform_sNewIndexes = computeWordsFromIndexes(t, n);
							
							var sNewWordform = sNewWordform_sNewIndexes[0];
							var sNewIndexes =  sNewWordform_sNewIndexes[1];
							
							// Write these into the right columns (both onto screen as into database)
							
							var oRow = fx.getRow(n);
							
							fx.putDataIntoCell(oRow, "wordform", sNewWordform);
							fx.putDataIntoCell(oRow, "onsetoffset", sNewIndexes);
							
							fx.updateDatabaseGivenACellOrRow(oRow, 
									{"wordform": removeTags(sNewWordform), "onsetoffset": sNewIndexes, "process_now": true}, 
									function(){
								
										// the function call will cause a trigger to be activated
										// so the following steps will happen:
										
										// [2] analyzed_wordforms for those words will be looked up
										//     (or will be created if they don't exist yet) and
										//     those analyzed_wordforms will be put in the same order as the wordforms  
										//   
										// N.B.: Sorting both wordform and analyzed_wordforms by onsets
										//       is needed to keep the relation between those three components, 
										//       since later on these data is processed back into the native 
										//       token_attestations table: this consists of separate records for each 
										//       analyzed_wordform, which of course need to refer to the
										//       correct wordform and onset (word position) in the quote.
										//       (see final step of trigger, calling api.process_new_token_attestations)								
										//
										// [3] as we're done with the worktable, we will need to update
										//     the native token_attestations table and clean up the paradigm 
										
										
										// when all this is done, this callback is called so:
										// refresh to see the results!
										
										fn.refreshTable("lemmata_and_paradigma");
										fn.refreshTable(t);
								
									}
							);
								
						}); // end of function								
					
				} // end of click event
			},
			"quote": {
				"colsort": "asc",
				"cell_tooltip": "Klik om woorden te (de)highlighten",
				"mouseup": function(t, n){
					
					// do we have a text selection?
					var oCell = 		fx.getCell(n);
					var oSelectedText =	fx.getSelectedTextInCell(oCell);
					
					
					// if selection is empty, that means that we've clicked on a word
					// without selecting it manually.
					// In this case, try to select the word that was clicked upon
					if (oSelectedText.text == '' && oSelectedText.reliable) {
						oSelectedText = fx.getWordClickedUponInCell(oCell);						
					}
					
					// if we have a selection now, process it
					if (oSelectedText.text!='' && oSelectedText.reliable) {
						
						// check if the selected text contains commas, which is not allowed since it is used as a separator
						if (oSelectedText.text.indexOf(",")>-1) {
							fn.message("Let op", "De gekozen tekst bevat komma's. Dat is niet toegestaan!");
						}
						
						else {
							// get the registered onsets and offsets
							
							// put the token indexes string into an array
							
							var sTokenIndexesIds = 		fx.getDataFromSiblingCell(oCell, "onsetoffset");
							var sOldTokenIndexesIds =	sTokenIndexesIds;
							var aTokenIndexesIds = 		(sTokenIndexesIds!='' && sTokenIndexesIds!= 'none') ?
														sTokenIndexesIds.split("\|") : new Array();
													
							// get the current screen selection
							var iStart =	parseInt(oSelectedText.start);
							var iEnd = 		parseInt(oSelectedText.end);
							
							
							// is this selection already part of the registered onsets and offsets?
							var iIndexOfThisPair = $.inArray(iStart+","+iEnd, aTokenIndexesIds);					
							
							// if token was already marked as token, remove it
							if (iIndexOfThisPair>-1) {
								aTokenIndexesIds.splice(iIndexOfThisPair, 1);							
							}
							// otherwise add the selected token(s)
							else {
								// remove the tokens that are within the selection (=overlap)
								// and add the selection as a whole after that
								
								var bAddSelection = true;
								for (var i=aTokenIndexesIds.length-1; i>=0; i--) {
																	
									var sOnePair = aTokenIndexesIds[i];
									var iOneStart = parseInt(sOnePair.split(",")[0]);
									var iOneEnd = parseInt(sOnePair.split(",")[1]);
									
									// if token is within the selection, remove it
									if (iStart<=iOneStart && iOneEnd<=iEnd)
										{
										aTokenIndexesIds.splice(i, 1);
										}
									// if selection is within/overlapping an existing token, do nothing
									else if ( ( iOneStart<=iStart && iStart<=iOneEnd ) ||
											  ( iOneStart<=iEnd   && iEnd<=iOneEnd   ) )
										{
										bAddSelection = false;
										}
										
								}
								// add the selection
								if (bAddSelection)
									aTokenIndexesIds.push(iStart+","+iEnd);
							}
							
							// update the database and the screen table
							
							// rebuild the token indexes string from the current array
							sTokenIndexesIds = aTokenIndexesIds.join("|");
							if (sTokenIndexesIds == '') 
								sTokenIndexesIds = "none";
							
							fn.showProcessingMsg(t);
							
							fx.updateDatabaseGivenACellOrRow(
									oCell, {"onsetoffset": sTokenIndexesIds}, 
									function(){
										fn.showProcessingMsg(t);
										
										var oRow = fx.getRowFromCell(oCell);
										fx.callRecord(oRow, ["quote", "onsetoffset"], function(){
											putHighlightOnOneRow(oRow);
											fn.removeProcessingMsg(t);
											
											// attract attention from user to this button, which must be pressed 
											// as soon as the quote was modified
											
											var blink = function(elem) {
											    $(elem).find("button").animate({
											        opacity: '0'
											    }, function(){
											        $(this).animate({
											            opacity: '1'
											        }, blink(elem));
											    });
											};										
											var nDoorvoeren = fn.getCellInRowNode(fn.getRowNode(n), "doorvoeren");
											$(nDoorvoeren).find("button")
												.css("background-color", "red")
												.css("color", "white");
											blink( nDoorvoeren );
										});										
									}
							); // end of fx.update
						}
						
					} // end of selection now processing
									
				} // end of mouseup event
			},
			
			"quote_vector": {
				"visible": false
			}
		}
};


