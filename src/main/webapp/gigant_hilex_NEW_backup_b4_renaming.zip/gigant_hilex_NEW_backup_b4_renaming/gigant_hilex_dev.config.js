
// ------------------------------------------------------------------------------------------------------------------
// Lex'it compulsory settings
// ------------------------------------------------------------------------------------------------------------------

// list of tables that must be hidden or visible (don't use both, it's a matter of what's the most convenient)
oHiddenTablesList = [];
oShowOnlyTables = ["analyzed_wordforms", "documents", "lemmata", "lemmata_and_paradigma", "multilemmata",
				 "marijke_spelling_giganthilex_differences",
				 "multiple_lemmata_analyses", "multiple_lemmata_analyses_view", "multiple_lemmata_analysis_parts",
				 "token_attestations", "token_attestations_worktable", "wordforms", 
				 "modified_lemmata_view", "modified_paradigm_view", "modified_attestations_view",
				 "ontbrekende_citaten", "double_quotations_id_to_check",
				 "mnw_wordforms_parts_of_speech", "mnw_lemma_parts_of_speech" ,
				 "missing_mnw_quotes_in_hilex", 
				 "wordforms_to_diminutives",
				 "possible_groups",
				 "lemmata_without_paradigm",
				 "quotation_section_id_of_token_attestations_with_clitics", "fishy_wordforms",
				 "ticket_179_possible_doubled_lemmata", "lemma_to_variants", "thomas_new_fabulous_table", "thomas_new_fabulous_table_premium"];

// containers for configuration of the tables
oTableSettingsList = {
	
};
oTableConfigurationList = {

    // set class for all cells of all tables
	"*": {
		"*": {
			"class": "inlfont10pt",
		}
	}
};


// ------------------------------------------------------------------------------------------------------------------
// Layout settings
// ------------------------------------------------------------------------------------------------------------------

// Huisstijl!
fn.setBalk(true, true, (document.URL.indexOf("localhost")<0 ? "../lexit2_config/gigant_hilex/":"") + "Icon_HiLex_small.gif");

fn.setProjectTitle("GiGaNT HiLex (development)");
fn.setProjectFont("Verdana, sans-serif, gtb", "10pt");

// needed to keep some columns narrow enough
fn.addCss(	"td.linebrk {white-space: normal; max-width: 220px !important} "+	
			"td.linebrk_wf {white-space: normal; max-width: 200px !important} "+
			"td.block {display: block}");


// ------------------------------------------------------------------------------------------------------------------
// Global settings
// ------------------------------------------------------------------------------------------------------------------

// Array's to store the locked lemmata of the current view
// Those array's get updated at each table draw
var aCurrentLemmaViewLocks = 		new Array();
var aCurrentParadigmaViewLocks =	new Array();

// notes key
var notesKey = "a";
var taNotesKey = "a";



// list of pid for diminutives job
var listOfPids4DiminutivesJob = null;
var diminutiveGroupsCursor = 0;
var iNumberOfPidsDiminutives = null;


// chosen super lemma storage
var sChosenSuperLemId;

// create a unique multibuilder_id
// (needed so the table used for building multiple lemmata can't be used by more than one user at the time:
//  we create a unique table and remove it afterwards)
var sMultiBuilderId = Math.floor(1000000*Math.random());
var sMultiBuilderTable = 'temp_multilemmata_builder_'+sMultiBuilderId;



//************************************************************************



// ------------------------------------------------------------------------------------------------------------------
// Libraries
// ------------------------------------------------------------------------------------------------------------------


// Our own libraries
// declare all needed files here!

var aLibrariesList = [
	
	"gigant_hilex.library.js",
	"gigant_hilex.utils.js",
	"gigant_hilex.autocomplete.js",
	
	"gigant_hilex.lemmata.js",
	"gigant_hilex.multiple_lemmata.js",		
	"gigant_hilex.paradigm.js",
	"gigant_hilex.token_attestations.js",
	"gigant_hilex.documents.js",
	
	"gigant_hilex.jobs.js",
	
	"gigant_hilex.logs.js"
];


// function for loading libraries sequentially
function loadLibraries(aLibrariesList, i, fnCallback){
		
	var bForceLocal = (paramsHash!=null && paramsHash.get("test")!=null && paramsHash.get("test")=="true");
	
	if (aLibrariesList[i] != null) {
		var sPrefix = (bForceLocal ? "" : "../lexit2_config/gigant_hilex/");
		fn.getLibrary(sPrefix + aLibrariesList[i], function(){
			loadLibraries(aLibrariesList, i+1, fnCallback);
		});
	}
	else {
		fnCallback();
	}
};




// ------------------------------------------------------------------------------------------------------------------
// config of the tables
// ------------------------------------------------------------------------------------------------------------------

// help functions for configuration, which will be called by the initializeTables() function

function addSettings(oAdditionalSettings){
	return $.extend(true, oTableSettingsList, oAdditionalSettings);
};
function addConfig(oAdditionalConfig){
	return $.extend(true, oTableConfigurationList, oAdditionalConfig);
};

 
// this function has to be called when all libraries have been loaded:
// it initializes the tables

function initializeTables(){
	
	// lemmata
	addSettings(hilexlem.settings);
	addConfig(hilexlem.config);
	
	// multiple lemmata
	addSettings(hilexmultilem.settings);
	addConfig(hilexmultilem.config);
	
	// paradigm
	addSettings(hilexparadigm.settings);
	addConfig(hilexparadigm.config);
	
	// jobs
	addSettings(hilexjobs.settings);
	addConfig(hilexjobs.config);
	
	// token attestations
	addSettings(hilexattestations.settings);
	addConfig(hilexattestations.config);
	
	// documents
	addSettings(hilexdocs.settings);
	addSettings(hilexdocs.config);
	
	// log
	addSettings(hilexlogs.settings);
	addConfig(hilexlogs.config);
	
	
	
	
	// initialize the multilemmata builder
	hilexlib.createMultiLemmataBuilder();
	
	// reload the list of tables 
	fn.rebuildTablesMenu();
}



// start loading libraries 
// and initialize the tables when all libraries
// are loaded
	
$("#tablechoice").hide();
fn.closeDialog();
fn.message("Loading", "Loading libraries...");

loadLibraries(aLibrariesList, 0, function(){
	
	$("#tablechoice").show();	
	
	// when all libraries are ready, initialize
	initializeTables();	
	
	fn.closeDialog();
});
	


//************************************************************************


$(document).ready(function() {
	
	// check if working in Hilex is allowed now
	fn.callFunction("api.test_sync", [], function(response){
		
		if (response["test_sync"] != "Synchronisatie staat AAN"){
			fn.message("LET OP", "Let op: Hilex is heel even uit de lucht (er wordt een update gedraaid). Kom over een paar minuten terug.", function(){
				$("#selected_source").remove();
				$("#indicator").remove();
			});
		}
		
	});
	
});


//************************************************************************
